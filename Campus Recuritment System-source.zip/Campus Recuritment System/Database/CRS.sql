-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 19, 2018 at 12:51 PM
-- Server version: 10.2.15-MariaDB-log
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `s170213b_campus`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `Date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `Date`) VALUES
(1, 'navi123', 'navi123', '2018-04-16 10:44:30');

-- --------------------------------------------------------

--
-- Table structure for table `applied_students`
--

CREATE TABLE `applied_students` (
  `id` int(11) NOT NULL,
  `st_name` varchar(150) NOT NULL,
  `st_father` varchar(150) NOT NULL,
  `st_college` varchar(200) NOT NULL,
  `st_course` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `st_resume` varchar(100) NOT NULL,
  `st_mobile` varchar(15) NOT NULL,
  `st_email` varchar(100) NOT NULL,
  `st_image` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applied_students`
--

INSERT INTO `applied_students` (`id`, `st_name`, `st_father`, `st_college`, `st_course`, `qualification`, `st_resume`, `st_mobile`, `st_email`, `st_image`) VALUES
(1, 'jasvir singh', 'kewal krishan', 'ggscmit', 'MCA', 'Post Grduate', 'EME Test.pdf', ' 9855381714', 'jassitoora@gmail.com', 'event.jpg'),
(2, 'bjj', 'jhhu', 'hjuhuhu', 'hujhuhu', 'hbjuhuhu', 'A1040662108_18710_14_2017_IndustryInternshipGuidelines2018.pdf', ' 988767876677', 'jass@gmail.com', 'contact.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `college_users`
--

CREATE TABLE `college_users` (
  `id` int(11) NOT NULL,
  `college_name` varchar(150) NOT NULL,
  `admin_name` varchar(100) NOT NULL,
  `admin_designation` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `token` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `college_users`
--

INSERT INTO `college_users` (`id`, `college_name`, `admin_name`, `admin_designation`, `address`, `mobile`, `email`, `password`, `token`) VALUES
(1, 'nkjhjbbbj', 'nbtynbtnt', 'grtbtrbht', 'trbtrbtbgb', 'gtbtgbtgb', 'fklgnkl@gntynytnytn', '', ''),
(3, '', '', '', '', '', 'jassitoora9@gmail.com', '58b3aac15c283e000acbf5b73dd14b110a752b4f', 'grijv'),
(4, 'nlkji', 'hihiu', 'ihkhh', 'uhuhuh', 'uhuhuh', 'jassitoora9@gmail.com', '0c05df3634f8e3f4456ec33a4e7c300e56163757', ''),
(5, 'hkjhuu', 'huhuuh', 'huhuhuu', 'uhuhuhu', 'uhuhuhuh', 'jassitoora9@gmail.com', '0c05df3634f8e3f4456ec33a4e7c300e56163757', ''),
(6, 'jgjhHKJHK', 'lkhkj', 'gj', 'jhuih', 'hhh', 'jassitoora9@gmail.com', '0c05df3634f8e3f4456ec33a4e7c300e56163757', ''),
(7, 'hkjhj', 'hhhh', 'hjhh', 'khkhkh', 'khkhkh', 'jstoora@gmail.com', '6575de1fa7cbd2c2fff4dfefe32b9f82aff27732', '');

-- --------------------------------------------------------

--
-- Table structure for table `companies_detail`
--

CREATE TABLE `companies_detail` (
  `id` int(11) NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact_detail` varchar(100) NOT NULL,
  `requirment` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companies_detail`
--

INSERT INTO `companies_detail` (`id`, `company_name`, `department`, `address`, `contact_detail`, `requirment`) VALUES
(1, 'HCL Pvt', 'web development', 'sco-98,mohali', 'phn-985567374,jassitoora9@gmail.com', 'php developer');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

CREATE TABLE `company` (
  `id` int(11) NOT NULL,
  `cpname` varchar(150) NOT NULL,
  `empname` varchar(50) NOT NULL,
  `emp_position` varchar(60) NOT NULL,
  `industry` varchar(50) NOT NULL,
  `email` varchar(60) NOT NULL,
  `password` varchar(50) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `url` varchar(200) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `Time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `cpname`, `empname`, `emp_position`, `industry`, `email`, `password`, `contact`, `url`, `address`, `Time`) VALUES
(2, 'The Brishpati infotech', 'navdeep', 'COO', 'Web Development', 'info@brihaspatitech.com', 'info123', '8146050001', 'https://www.brihaspatitech.com/', 'F - 169, Sector 74, Phase - 8B\r\nIndustrial Focal Point, Mohali (Punjab), India', '2018-04-20 08:58:43'),
(3, 'BayaTree', 'Suresh', 'Senior Technical Supervisior', 'Web Development', 'info@bayatree.com', 'bayatree', '3164796489', 'https://bayatree.com/', 'C-139, Ind. Area, Phase -VIII\r\nS.A.S. Nagar\r\nMohali â€“ 160059, Punjab\r\nIndia', '2018-04-25 05:53:51');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `cpname` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `message` varchar(600) NOT NULL,
  `rec_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `cpname`, `title`, `image`, `message`, `rec_time`) VALUES
(10, 'BayaTree', 'Technology', '4K_SwjZMdBJ1orh8em.jpg', 'This is a new technology ', '2018-05-12 08:51:26');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `cpname` varchar(100) NOT NULL,
  `title` varchar(60) NOT NULL,
  `message` varchar(600) NOT NULL,
  `rec_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `requirment`
--

CREATE TABLE `requirment` (
  `id` int(11) NOT NULL,
  `job_profile` varchar(100) NOT NULL,
  `skills` varchar(600) NOT NULL,
  `email` varchar(150) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `requirment`
--

INSERT INTO `requirment` (`id`, `job_profile`, `skills`, `email`, `date`) VALUES
(3, 'PHP Developer', 'php,html5,javascript', 'info@websterztech.com', '2018-05-04 18:08:52');

-- --------------------------------------------------------

--
-- Table structure for table `student_register`
--

CREATE TABLE `student_register` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `f_name` varchar(100) NOT NULL,
  `college_detail` varchar(200) NOT NULL,
  `course` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `resume` varchar(150) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `token` varchar(150) NOT NULL,
  `image` varchar(150) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_register`
--

INSERT INTO `student_register` (`id`, `name`, `f_name`, `college_detail`, `course`, `qualification`, `resume`, `mobile`, `email`, `password`, `token`, `image`, `date`) VALUES
(2, '', '', '', '', '', '', '9855381714', 'jassitoora9@gmail.com', 'jassi98553', 'pls9u5a', '', '2018-05-16 04:54:38'),
(3, '', '', '', '', '', '', ' ', 'jassitoora@gmail.com', '0c05df3634f8e3f4456ec33a4e7c300e56163757', '', '', '2018-05-11 10:28:25'),
(4, 'bkjkjn', 'hlkjhhokho', 'hohouhuh', 'huhuhu', 'uhuu', 'EME Test.pdf', ' 987875788685', 'jstoora@gmail.com', '6575de1fa7cbd2c2fff4dfefe32b9f82aff27732', '', 'desktop2.jpg', '2018-05-12 06:45:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `applied_students`
--
ALTER TABLE `applied_students`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `college_users`
--
ALTER TABLE `college_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `companies_detail`
--
ALTER TABLE `companies_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `company`
--
ALTER TABLE `company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requirment`
--
ALTER TABLE `requirment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_register`
--
ALTER TABLE `student_register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `applied_students`
--
ALTER TABLE `applied_students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `college_users`
--
ALTER TABLE `college_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `companies_detail`
--
ALTER TABLE `companies_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `company`
--
ALTER TABLE `company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `requirment`
--
ALTER TABLE `requirment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `student_register`
--
ALTER TABLE `student_register`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
