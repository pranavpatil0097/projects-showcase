<?php
session_start();
if ($_SESSION['mobile']=="") {
    header("location:col_login.php");
    exit();  
}
?>


<!DOCTYPE html>
<html>

<head>
    <title></title>
    </style>
</head>

<body>
    <div class="st-back">
        <?php include("st_header.php");?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12" style="height: 200px">
                </div>
                <div class="col-lg-4 col-sm-3">
                </div>
                <div class="col-lg-4 col-sm-6 st-password">
                    <h1>Change Password</h1>
                    <form>
                        <div class="input-group">
                            <input type="text" class="form-control" name="" placeholder="Old Password">
                        </div>
                        <br/>
                        <div class="input-group">
                            <input id="password" type="text" class="form-control" name="password" placeholder="New Password">
                        </div>
                        <br/>
                        <div class="input-group">
                            <input type="text" class="form-control" name="" placeholder="Confirm Password">
                        </div>
                        <br/>
                        <div class="btn-group-sm">
                            <input type="submit" value="Change" name="" class="btn btn-success">&nbsp &nbsp &nbsp &nbsp
                            <input type="" name="" value="Cancel" class="btn btn-danger" style="width:205px; ">
                        </div>
                    </form>
                </div>
                <div class="col-lg-4 col-sm-3">
                </div>
            </div>
        </div>
        <div style="margin-top: 300px;">
        <?php include("col_footer.php");?>
    </div>
    </div>
    
    <div class="row">
        <div class="col-lg-12 col-sm-12" style="margin-right: 0px;">
            <footer class="st-footer text-center"> Campus Recruitment System @ 2018 ! Privacy Policy</footer>
        </div>
    </div>
</body>

</html>