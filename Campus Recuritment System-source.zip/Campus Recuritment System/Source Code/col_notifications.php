<?php
session_start();
if ($_SESSION['email']=="") {
    header("location:col_login.php");
    exit();  
}
?>


<!DOCTYPE html>
<html>

<head>
    <title>Notifications</title>
</head>

<body>
   <?php include("col_header.php");?>
    <div class="container-fluid">
        <div class="row">
            
                <h1 class="text-center">Notifications</h1>
                <div class="col-lg-12" style="height: 800px;">
                <table border="2" width="100%" cellpadding="10">
                    <tr height="20px">
                        <td>bdbfh</td>
                    </tr>
                     <tr>
                        <td>bdbfh</td>
                    </tr>
                     <tr>
                        <td>bdbfh</td>
                    </tr>
                     <tr>
                        <td>bdbfh</td>
                    </tr>
                     <tr>
                        <td>bdbfh</td>
                    </tr>
                     <tr>
                        <td>bdbfh</td>
                    </tr>
                </table>
            </div>
        </div>
    </div><br/>
   <?php include("col_footer.php");?>
</body>

</html>