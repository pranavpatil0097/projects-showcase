<?php
$conn         = mysqli_connect("localhost", "root", "", "crs") or die("Connection is not established");
$del='DELETE FROM events WHERE rec_time < DATE_SUB(NOW(), INTERVAL 7 DAY);';
$delquery    = mysqli_query($conn, $del);
$showq        = "select * from events order by id desc";
$showquery    = mysqli_query($conn, $showq);
$show_company = [];
$show_title   = [];
$show_image   = [];
$show_msg     = [];
$show_date    = [];
while ($show = mysqli_fetch_array($showquery)) {
    $show_company[] = $show['cpname'];
    $show_title[]   = $show['title'];
    $show_image[]   = $show['image'];
    $show_msg[]     = $show['message'];
    $show_date[]    = $show['rec_time'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	 <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Campus Recruitment System</title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
	<a name="event" style="text-decoration: none;color: black">
        <div class="container-fluid" style="background-color: #ddd;">
            <div class="container event-container">
                <h1 class="text-center event-head w3-animate-fading" style="font-size: 50px;">Events</h1>

                <div class="container-fluid body">
                    <div class="carousel slide" id="event" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="item active">
                                <div class="event-style">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="col-lg-2 event">
                                                <h4 class="text-center"><?php if (!isset($show_title[0])) 
                                                {
                                                    $show_title[0]="";
                                                    if ($show_title[0] == "") {
                                                    echo "";
                                                    } 
                                                } else {echo $show_title[0];} ?></h4>
                                                <?php if (!isset($show_image[0])) 
                                                {
                                                    $show_image[0]="";
                                                    if ($show_image[0]=="") 
                                                    {
                                                        echo "";
                                                    } 
                                                }else 
                                                {
                                                    echo "<img src='Event_images/" . $show_image[0] . "' width='250' height='200'>";
                                                } ?>
                                            </div>
                                            <div class="col-lg-1"></div>
                                            <div class="col-lg-3 event">
                                                <h5 class="text-center"><?php if (!isset($show_date[0])) 
                                                {
                                                    $show_date[0]="";
                                                    if ($show_date[0]=="") 
                                                    {
                                                        echo "";
                                                    } 
                                                } else {echo $show_date[0];} ?></h5>
                                                <div class="row" style="width: 250px;height: 180px;">
                                                    <font color=#000><b><?php if (!isset($show_msg[0])) 
                                                    {
                                                        $show_msg[0]="";
                                                        if ($show_msg[0]=="") 
                                                        {
                                                            echo "<h4>No Event is Going on.</h4>";
                                                        } 
                                                    } else {echo $show_msg[0];} ?></b></font>
                                                </div>
                                                <div class="row">
                                                    <?php if (!isset($show_company[0])) 
                                                    {
                                                        $show_company[0]="";
                                                        if ($show_company[0]=="") 
                                                        {
                                                            echo "<h4>No Event is Going on.</h4>";
                                                        } 
                                                    } else {echo $show_company[0];} ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="col-lg-2 event">
                                                <h4 class="text-center"><?php if (!isset($show_title[1])) 
                                                {
                                                    $show_title[1]="";
                                                    if ($show_title[1] == "") {
                                                    echo "";
                                                    } 
                                                } else {echo $show_title[1];} ?></h4>
                                                <?php if (!isset($show_image[1])) 
                                                {
                                                    $show_image[1]="";
                                                    if ($show_image[1]=="") 
                                                    {
                                                        echo "";
                                                    } 
                                                }else 
                                                {
                                                    echo "<img src='Event_images/" . $show_image[1] . "' width='250' height='200'>";
                                                } ?>
                                            </div>
                                            <div class="col-lg-1"></div>
                                            <div class="col-lg-3 event">
                                                <h5 class="text-center"><?php if (!isset($show_date[1])) 
                                                {
                                                    $show_date[1]="";
                                                    if ($show_date[1]=="") 
                                                    {
                                                        echo "";
                                                    } 
                                                } else {echo $show_date[1];} ?></h5>
                                                <div class="row" style="width: 250px;height: 180px;">
                                                    <font color=#000><b><?php if (!isset($show_msg[1])) 
                                                    {
                                                        $show_msg[1]="";
                                                        if ($show_msg[1]=="") 
                                                        {
                                                            echo "<h4>No Event is Going on.</h4>";
                                                        } 
                                                    } else {echo $show_msg[1];} ?></b></font>
                                                </div>
                                                <div class="row">
                                                    <?php if (!isset($show_company[1])) 
                                                    {
                                                        $show_company[1]="";
                                                        if ($show_company[1]=="") 
                                                        {
                                                            echo "<h4>No Event is Going on.</h4>";
                                                        } 
                                                    } else {echo $show_company[1];} ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="item">
                                <div class="event-style">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="col-lg-2 event">
                                                <h4 class="text-center"><?php if (!isset($show_title[2])) 
                                                {
                                                    $show_title[2]="";
                                                    if ($show_title[2] == "") {
                                                    echo "";
                                                    } 
                                                } else {echo $show_title[2];} ?></h4>
                                                <?php if (!isset($show_image[2])) 
                                                {
                                                    $show_image[2]="";
                                                    if ($show_image[2]=="") 
                                                    {
                                                        echo "";
                                                    } 
                                                }else 
                                                {
                                                    echo "<img src='Event_images/" . $show_image[2] . "' width='250' height='200'>";
                                                } ?>
                                            </div>
                                            <div class="col-lg-1"></div>
                                            <div class="col-lg-3 event">
                                                <h5 class="text-center"><?php if (!isset($show_date[2])) 
                                                {
                                                    $show_date[2]="";
                                                    if ($show_date[2]=="") 
                                                    {
                                                        echo "";
                                                    } 
                                                } else {echo $show_date[2];} ?></h5>
                                                <div class="row" style="width: 250px;height: 180px;">
                                                    <font color=#000><b><?php if (!isset($show_msg[2])) 
                                                    {
                                                        $show_msg[2]="";
                                                        if ($show_msg[2]=="") 
                                                        {
                                                            echo "<h4>No Event is Going on.</h4>";
                                                        } 
                                                    } else {echo $show_msg[2];} ?></b></font>
                                                </div>
                                                <div class="row">
                                                    <?php if (!isset($show_company[2])) 
                                                    {
                                                        $show_company[2]="";
                                                        if ($show_company[2]=="") 
                                                        {
                                                            echo "<h4>No Event is Going on.</h4>";
                                                        } 
                                                    } else {echo $show_company[2];} ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-6">
                                            <div class="col-lg-2 event">
                                                <h4 class="text-center"><?php if (!isset($show_title[3])) 
                                                {
                                                    $show_title[3]="";
                                                    if ($show_title[3] == "") {
                                                    echo "";
                                                    } 
                                                } else {echo $show_title[3];} ?></h4>
                                                <?php if (!isset($show_image[3])) 
                                                {
                                                    $show_image[3]="";
                                                    if ($show_image[3]=="") 
                                                    {
                                                        echo "";
                                                    } 
                                                }else 
                                                {
                                                    echo "<img src='Event_images/" . $show_image[3] . "' width='250' height='200'>";
                                                } ?>
                                            </div>
                                            <div class="col-lg-1"></div>
                                            <div class="col-lg-3 event">
                                                <h5 class="text-center"><?php if (!isset($show_date[3])) 
                                                {
                                                    $show_date[3]="";
                                                    if ($show_date[3]=="") 
                                                    {
                                                        echo "";
                                                    } 
                                                } else {echo $show_date[3];} ?></h5>
                                                <div class="row" style="width: 250px;height: 180px;">
                                                    <font color=#000><b><?php if (!isset($show_msg[3])) 
                                                    {
                                                        $show_msg[3]="";
                                                        if ($show_msg[3]=="") 
                                                        {
                                                            echo "<h4>No Event is Going on.</h4>";
                                                        } 
                                                    } else {echo $show_msg[3];} ?></b></font>
                                                </div>
                                                <div class="row">
                                                    <?php if (!isset($show_company[3])) 
                                                    {
                                                        $show_company[3]="";
                                                        if ($show_company[3]=="") 
                                                        {
                                                            echo "<h4>No Event is Going on.</h4>";
                                                        } 
                                                    } else {echo $show_company[3];} ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a class="left carousel-control" href="#event" data-slide="prev">
                            <span class="glyphicon glyphicon-chevron-left"></span>
                            <span class="sr-only">Previous</span>
                        </a>
                        <a class="right carousel-control" href="#event" data-slide="next">
                            <span class="glyphicon glyphicon-chevron-right"></span>
                            <span class="sr-only">Next</span>
                        </a>
                    </div>
                </div>


            </div>
        </div>
    </a>
</body>
</html>