<?php
if ($_SESSION['nm']=="") {
    echo "<script>location.href='CP_login.php';</script>";  
}
$name    = $_SESSION['nm'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Welcome</title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/main.css">
    <link rel="stylesheet" type="text/css" href="CSS/company.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">
                    <img src="images/logo.png">
                </a>
            </div>
            <div class="collapse navbar-collapse bt-size" id="myNavbar">
                <ul class="nav navbar-nav navbar-s">
                    <li class="active"><a href="CP_main.php">Home</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggel="dropdown">Events</a>
                        <ul class="dropdown-menu">
                            <li><a href="#" data-toggle="modal" data-target="#exampleModal" data-whatever="@Events">Post Events</a></li>
                            <li><a href="CP_showevent.php">Show Events</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggel="dropdown">News</a>
                        <ul class="dropdown-menu">
                            <li><a href="#" data-toggle="modal" data-target="#news" data-whatever="@News">Post News</a>
                            </li>
                            <li><a href="CP_shownews.php">Show News</a></li>
                        </ul>
                    </li>
                    <li><a href="CP_postrequirment.php">Post Requirment</a></li>
                    <li><a href="CP_main.php #contact">Contact</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggel="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <span class="glyphicon glyphicon-user"></span>&nbsp<?php echo $name; ?>
                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="CP_editprofile.php">Edit Profile</a></li>
                            <li><a href="CP_Changepass.php">Change Password</a></li>
                            <li><a href="CP_logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
</body>
</html>