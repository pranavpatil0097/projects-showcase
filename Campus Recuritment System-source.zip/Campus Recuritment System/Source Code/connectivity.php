 <?php
 // create cponnection
$con=mysqli_connect("localhost","root","","crs");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>
