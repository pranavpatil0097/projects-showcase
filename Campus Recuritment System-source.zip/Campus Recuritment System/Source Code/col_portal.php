<?php
session_start();
if ($_SESSION['email']=="") {
    header("location:col_login.php");
    exit();  
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>College portal</title>
    
</head>

<body>
    <?php include("col_header.php"); ?>
        <div class="container-fluid">
        <div class="row">
            <div class="col-lg-6 text-justify" style="margin-top: 40px;">
                <h1 class="text-center">Our Services</h1>
                <p>
                    Welcome College ADmin Check here for the companies recruiters which vcamm improbe your bussinessw and may giv oppourni o he sudenms o place hem in mnc copmpanuies. A college (Latin: collegium) is an educational institution or a constituent part of one. A college may be a degree-awarding tertiary educational institution, a part of a collegiate or federal university, or an institution offering vocational education. In the United States, "college" may refer to a constituent part of a university or to a ... A college (Latin: collegium) is an educational institution or a constituent part of one. A college may be a degree-awarding tertiary educational institution, a part of a collegiate or federal university, or an institution offering vocational education. In the United States, "college" may refer to a constituent part of a university or to a ...
                </p>
            </div>
            <div class="col-our-services">
                <img src="images/OurServices.jpg" alt="image not found" class="img-thumbnail">
            </div>
        </div>
    </div>
    <br/>
    <br/>
    <div class="container-fluid" style="margin: 25px -15px 25px -15px;">
        <div class="col-events">
            <div class="row">
                <div class="col-lg-4 ">
                    <div class="col-heading">
                        <h1>Events</h1>
                    </div>
                    <br/>
                    <h3>Youth vibe</h3>
                    <div style="overflow-x: auto;">
                    <textarea cols="55" rows="10">
                        Welcome College ADmin Check here for the companies recruiters which vcamm improbe your bussinessw and may giv oppourni o he sudenms o place hem in mnc copmpanuies. A college (Latin: collegium) is an educational institution or a constituent part of one. A college may be a degree-awarding tertiary educational institution, a part of a collegiate or federal university, or an institution offering vocational education.
                    </textarea>
                    </div>
                </div>
                <div class="col-lg-4" style="border-left: 1px solid black;">
                    <div class="col-heading">
                        <h1>Messages</h1>
                    </div>
                    <br/>
                    <h3>Lec.Sonali Bhardwaj</h3>
                    <div style="overflow-x: auto;">
                    <textarea cols="55" rows="10">
                        Welcome College ADmin Check here for the companies recruiters which vcamm improbe your bussinessw and may giv oppourni o he sudenms o place hem in mnc copmpanuies. A college (Latin: collegium) is an educational institution or a constituent part of one. A college may be a degree-awarding tertiary educational institution, a part of a collegiate or federal university, or an institution offering vocational education.
                    </textarea>
                    </div>
                </div>
                <div class="col-lg-4" style="border-left: 1px solid black;">
                    <div class="col-heading">
                        <h1>Recruiters</h1>
                    </div>
                    <br/>
                    <h3>HCL (Mohali)</h3>
                    <div style="overflow-x: auto;">
                    <textarea cols="55" rows="10">
                        Welcome College ADmin Check here for the companies recruiters which vcamm improbe your bussinessw and may giv oppourni o he sudenms o place hem in mnc copmpanuies. A college (Latin: collegium) is an educational institution or a constituent part of one. A college may be a degree-awarding tertiary educational institution, a part of a collegiate or federal university, or an institution offering vocational education.
                    </textarea>
                    </div>
                </div>
            </div>
        </div>
    </div><br/><br/>

    <?php include("col_footer.php");?>
</body>

</html>