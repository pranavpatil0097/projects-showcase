<?php 
session_start();
$name=$_SESSION['nm'];
$conn=mysqli_connect("localhost","root","","crs") or die("Connection is not istablished");
$q="select * from Company where email='".$name."'";
$query=mysqli_query($conn,$q);
while ($data=mysqli_fetch_array($query)) 
{
    $cp_name=$data['cpname'];
    $emp_name=$data['empname'];
    $emp_pos=$data['emp_position'];
    $ind=$data['industry'];
    $email=$data['email'];
    $contact=$data['contact'];
    $url=$data['url'];
    $add=$data['address'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Edit Profile</title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/main.css">
    <link rel="stylesheet" type="text/css" href="CSS/company.css">
    <link rel="stylesheet" type="text/css" href="CSS/companyRegistration.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">
                    <img src="images/logo.png">
                </a>
            </div>
            <div class="collapse navbar-collapse bt-size" id="myNavbar">
                <ul class="nav navbar-nav navbar-s">
                    <li><a href="CP_main.php">Home</a></li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggel="dropdown">Events</a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Post Events</a></li>
                            <li><a href="#">Show Events</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggel="dropdown">News</a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Post News</a></li>
                            <li><a href="#">Show News</a></li>
                        </ul>
                    </li>
                    <li class="active"><a href="CP_editprofile.php">Edit Profile</a></li>
                    <li><a href="CP_Changepass.php">Change Password</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span class="glyphicon glyphicon-user"></span>&nbsp<?php echo $name; ?>
                        </a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    <!-- Registration Details -->
    <div class="container-fluid company-back body">
        <div class="company-back-dt">
            <div class="container log-div">
                <h1 class="text-center">Edit Profile</h1>
                <br>
                <br>
                <form method="POST">
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Name Of Company :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="text" size="40" name="company-name" value="<?php echo $cp_name; ?>">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Name Of Company Employee :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="text" size="40" name="employee-name" value="<?php echo $emp_name; ?>" disabled>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Position Of Employee :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="text" size="40" name="employee-pos" value="<?php echo $emp_pos; ?>" disabled>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Industry :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="text" size="40" name="industry" value="<?php echo $ind; ?>" disabled>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            E-mail Of Company :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="email" size="40" name="company-email" value="<?php echo $email; ?>" disabled>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Contact No. :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="text" size="40" name="contact" value="<?php echo $contact; ?>">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Enter Company URL :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="text" size="40" name="url" value="<?php echo $url; ?>">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Address Of Company :
                        </div>
                        <div class="col-sm-5">
                            <textarea class="input-field" cols="30" rows="5" name="address"><?php echo $add; ?></textarea>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3 text-center">
                            <input class="btn btn-success" type="submit" name="submit" value="Submit">
                        </div>
                        <div class="col-sm-5">
                            <input class="btn btn-danger" type="submit" name="reset" value="Cancel">
                        </div>
                    </div>
                    <br>
                </form>
                <?php
                if (isset($_POST['submit'])) 
                {
                    $cp_nm=$_POST['company-name'];
                    $con=$_POST['contact'];
                    $nw_url=$_POST['url'];
                    $nw_add=$_POST['address'];
                    $newq="update company set cpname='".$cp_nm."',contact='".$con."',url='".$nw_url."',address='".$nw_add."' where email='".$email."';";
                    $newquery=mysqli_query($conn,$newq);
                    if ($newquery==true) 
                    {
                        echo "<script>
                                alert('Profile Sucessfully Updated');
                              </script>";
                    }
                    else
                    {
                        echo "<script>
                                alert('Profile Update Faield');
                              </script>";
                    }
                }
                else if (isset($_POST['reset']))
                {
                    echo "<script>location.href='CP_main.php';</script>";
                }
                ?>
            </div>
        </div>
    </div>

    <footer class="footer panel-footer text-center">
        <p>Campus Recruitment System &copy 2018 | Privacy Ploicy</p>
    </footer>
</body>
</html>