<?php
session_start();
if ($_SESSION['uid']=="") 
{
    header("location:Ad_login.php");
}
else
{
    $name=$_SESSION['uid'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Welcome <?php echo $name; ?></title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/Admin.css">
</head>

<body>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">
            		<img src="images/logo.png">
            	</a>
            </div>
            <div class="collapse navbar-collapse bt-size" id="myNavbar">
                <ul class="nav navbar-nav navbar-s">
                    <li class="active"><a href="Ad_main.php">Home</a></li>
                    <li><a href="#">Student</a></li>
                    <li><a href="Ad_Company.php">Company</a></li>
                    <li><a href="#">College or University</a></li>
                    <li><a href="Ad_events.php">Events</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="Ad_logout.php"><span class="glyphicon glyphicon-user"></span>&nbsp<?php echo $name; ?></a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    <!-- Admin Login -->
    <div class="container-fluid back body size">
        <marquee direction="left" scrolldelay=100><font color=#2f2><i><h1>Welcome <?php echo $name; ?> Admin ..!</h1></i></font></marquee>
    </div>
    <footer class="footer panel-footer text-center">
    	<p>Campus Recruitment System &copy 2018 | Privacy Ploicy</p>
    </footer>
</body>
</html>