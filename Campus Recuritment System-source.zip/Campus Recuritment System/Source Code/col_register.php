<!DOCTYPE html>
<html>

<head>
    <title>Edit College Profile</title>
</head>

<body>
    <?php include("col_header.php");?>
        <div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-1 col-sm-2"></div>
                <div class="col-lg-10 col-sm-8 college_profile_edit">
                    <h1> College Register Form </h1>
                    <form method="post">
                        <input type="text" name="college_name" class="form-control" placeholder=" College Name">
                        <br/>
                        <input type="text" name="admin_name" class="form-control" placeholder="Admin Name">
                        <br/>
                        <input type="text" name="admin_designation" class="form-control" placeholder="Admin Designation"><br/>
                        <input type="text" name="address" class="form-control" placeholder="Address">
                        <br/>
                        <input type="text" name="mobile" class="form-control" placeholder="Mobile">
                        <br/>
                        <input type="Email" name="email" class="form-control" placeholder="Email">
                        <br/></br>
                        <input type="submit" name="submit" value="Register" class="btn-primary form-control"><br/><br/>
                        <input type="reset" name="" value="Reset" class="btn-primary form-control">
                    </form>
                </div>
                <div class="col-lg-1 col-sm-2"></div>
            </div>
        </div>
    </div>
    <?php include("col_footer.php");?>
</body>
</html>
<?php
include("connectivity.php");
if(isset($_POST['submit']))
{
    $college_name=$_POST['college_name'];
    $admin_name=$_POST['admin_name'];
    $admin_designation=$_POST['admin_designation'];
    $address=$_POST['address'];
    $mobile=$_POST['mobile'];
    $email=$_POST['email'];


    $query="insert into college_users (college_name,admin_name,admin_designation,address,mobile,email)values('$college_name','$admin_name','$admin_designation','$address','$mobile','$email');";

     if (mysqli_query($con,$query)) 
       { 
          echo "<script> alert('Registered Successfully');</script>.";
          header("location:index.php");
       }
    else
       {
          echo "Error: " . $query . "<br>" . mysqli_error($con);
       }
         
}
 mysqli_close($con);
?>