<!DOCTYPE html>
<html>

<head>
    <title>Student Register</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <script src="js/jquery.js"></script>
    <script src="bootstrap/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
    <div class="jumbotron st-nav">
        <div class="crs-logo">
            <img class="img-responsive" src="images/CRS.png" style="position: absolute;">
        </div>
        <div>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" style="" id="nav">
            <nav class="text-right">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="">Guidlines</a></li>
                    <li><a href="com_details.php">Check For Jobs</a></li>
                    <li><a href="#contact">Contact Us</a></li>
                </ul>
            </nav>
        </div>
    </div>
    <div class="container-fluid st-login-back">
        <div class="row">
            <div class="col-lg-12" style="height: 200px;"></div>
            <div class="col-lg-7 col-sm-7">
                <div class="st-login">
                    <form method="post" enctype="multipart/form-data">
                        <h1>Student Registration</h1>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                            <input id="" type="text" class="form-control" name="st_name" placeholder="Student Name">
                        </div>
                        <br/>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                            <input id="" type="text" class="form-control" name="st_f_name" placeholder="Father Name">
                        </div>
                        <br/>
                         <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                            <input id="" type="text" class="form-control" name="st_college" placeholder="College Name & Address">
                        </div>
                        <br/>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                            <input id="" type="text" class="form-control" name="st_course" placeholder="Course">
                        </div><br/>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                            <input id="" type="text" class="form-control" name="st_qualification" placeholder="Qualification">
                        </div><br/>
                        <label>Upload Resume</label>
                        <input id="" type="file" name="st_resume" value="Upload Resume">
                         <br/>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                            <input id="" type="text" class="form-control" name="st_mobile" placeholder="Mobile">
                        </div><br/>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                            <input id="" type="email" class="form-control" name="st_email" placeholder="Email Address">
                        </div><br/>
                         <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                            <input id="" type="text" class="form-control" name="st_password" placeholder="Create Password  eg. jasvir@9867">
                        </div> <p>Password Should Have Conain Numbers,Special Character and Alphabets</p><br/>
                        
                             <label>Upload Image</label>
                            <input id="" type="file" name="st_image" placeholder="Upload Image"><br/>
                        
                        <div class="btn-group-sm">
                            <input type="submit" value="Register" name="register" class="btn btn-primary">
                            <input type="reset" name="reset" value="Reset" class="btn btn-primary">
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-3 st-login-text">
                 <h3>Dear</h3> Student Register here to see the opportunities for your  dream job. 
                While registering enter the details very carefully.if you have allready an account then <a href="st_login.php">Login Here</a> .  
                
            </div>
        </div>
        <div style="margin-top: 150px; margin-left: -15px;margin-right: -15px;">
            <?php include("col_footer.php");?>
        </div>
        <div class="row">
            <div class="col-lg-12 col-sm-12" style="margin-right: 0px;">
                <footer class="st-footer text-center"> Campus Recruitment System @ 2018 ! Privacy Policy</footer>
            </div>
        </div>
    </div>
</body>

</html>

<?php 

if(isset($_POST['register']))
{
    $st_name=$_POST['st_name'];
    $st_f_name=$_POST['st_f_name'];
    $st_college=$_POST['st_college'];
    $st_course=$_POST['st_course'];
    $st_qualification=$_POST['st_qualification'];
   
    $resume_file=$_FILES['st_resume']['name'];
    $resume_temp=$_FILES['st_resume']['tmp_name'];
    $resume_size=$_FILES['st_resume']['size'];
    $resume_extension=explode('.',$resume_file);
    $resume_extension=strtolower(end($resume_extension));
    $new_resume_name=uniqid().'.'.$resume_extension;
    $resume_store="st_resume/".$new_resume_name;

    $st_mobile=$_POST['st_mobile'];
    $st_email=$_POST['st_email'];
    $st_password=$_POST['st_password'];


    $st_image_name=$_FILES['st_image']['name'];
    $f_temp=$_FILES['st_image']['tmp_name'];
    $f_size=$_FILES['st_image']['size'];
    $f_extension=explode('.',$st_image_name);
    $f_extension=strtolower(end($f_extension));
    $new_file_name=uniqid().'.'.$f_extension;
    $store="st_images/".$new_file_name;

    if($f_extension=='jpg' || $f_extension=='png' || $f_extension=='jpeg' || $f_extension=='gif' && $resume_extension=='pdf')
    {
      if($resume_size>=1000000 && $f_size>=1000000)
      {
        echo "<script>alert('File Shoulde be 1 Mb max size.')</script>";
      }
      else
      {
         move_uploaded_file($resume_temp,$resume_store); 
         move_uploaded_file($f_temp,$store);
      }
    }
      include("connectivity.php");

     $query="insert into student_register(name,f_name,college_detail,course,qualification,resume,mobile,email,password,image)values('$st_name','$st_f_name','$st_college','$st_course','$st_qualification','$resume_file',' $st_mobile','$st_email','$st_password','$st_image_name');";

    if (mysqli_query($con,$query)) 
        { 
          echo "<script> alert('Registered Successfully');</script>.";
           header("location:index.php");
        }
    else
        {
          echo "Error: " . $query . "<br>" . mysqli_error($con);
        }
}
 mysqli_close($con);
?>