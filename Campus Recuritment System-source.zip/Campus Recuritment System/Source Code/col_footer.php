<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
   <div class="col-bottom text-justify">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3 col-sm-3 col-bottom-content">
                    <ul>
                        <h1>Contact Us</h1>
                        <li><a href=""> www.crsRecruiters.com,</a></li>
                        <li><a href="">crs.navjas@gmail.com</a></li>
                        <li><a href="">cont.9855381714</a></li>    
                    </ul> 
                   
                </div>
                <div class="col-lg-1 col-sm-1"></div>
                <div class="col-lg-3 col-sm-3 col-bottom-content">
                    <h1>News Letter</h1>
                    <input type="email" name="" class="form-control" placeholder="Email">
                    <input type="submit" name="" class="form-control btn-primary" style="width: 300px;">
                </div>
                <div class="col-lg-1"></div> 
                <div class="col-lg-3 col-sm-3 col-bottom-content">
                      <ul>
                         <h1>Follow Us</h1> 
                        <li><a href="">Twitter</a></li>
                        <li><a href="">Facebook</a></li>
                        <li><a href="">Instagram</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</body>
</html>