<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Company LogIn</title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/main.css">
    <link rel="stylesheet" type="text/css" href="CSS/companyRegistration.css">
    <link rel="stylesheet" type="text/css" href="CSS/companylogin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
	<nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">
            		<img src="images/logo.png">
            	</a>
            </div>
            <div class="collapse navbar-collapse bt-size" id="myNavbar">
                <ul class="nav navbar-nav navbar-s">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="index.php #about">About</a></li>
                    <li><a href="index.php #event">Events</a></li>
                    <li><a href="index.php #news">News</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        	<span class="glyphicon glyphicon-user"></span>&nbspLogIn
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="st_login.php">As Student</a></li>
                            <li><a href="CP_login.php">As Company</a></li>
                            <li><a href="col_login.php">As College or University</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggel="dropdown">
                    		<span class="glyphicon glyphicon-log-in"></span>&nbspRegister
                    	</a>
                        <ul class="dropdown-menu">
                            <li><a href="#">As Student</a></li>
                            <li><a href="CP_Registration.php">As Company</a></li>
                            <li><a href="#">As College or University</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    <div class="container-fluid company-back body">
    	<div class="company-back-dt">
    		<div class="container">
    			<div class="row">
    				<div class="col-sm-4"></div>
    				<div class="col-sm-4 log-div">
    					<h2>Company LogIn</h2><br>
    					<form method="POST">
                            <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                            <input class="input-sm input-field" type="text" name="user" placeholder="Enter Your Email">
                            </div><br>
                            <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                            <input class="input-sm input-field" type="password" name="pass" placeholder="Enter Your Password">
                            </div><br>
                            <input class="btn btn-primary" type="submit" name="login" value="Login">&nbsp&nbsp
                            <a href="forgetpass.php"><input class="btn btn-danger" type="button" name="forgetpass" value="Forget Password?"></a>               
                        </form>
    				</div>
    				<div class="col-sm-4"></div>
    			</div>
    		</div>
    	</div>
    </div>
    <?php
    if (isset($_POST['login'])) 
    {
        $user=$_POST['user'];
        $pass=$_POST['pass'];

        if ($user=="" && $pass=="") 
        {
            echo "<script>
                        alert('Please fill Username or Password First.Thank You!');
                      </script>";
        }
        else
        {
            $conn=mysqli_connect("localhost","root","","crs") or die("Connection is not established");
        $q="select * from company where email='".$user."' && password='".$pass."';";
        $query=mysqli_query($conn,$q);
        while ($data=mysqli_fetch_array($query)) 
        {
            if ($data['email']==$user && $data['password']==$pass) 
            {
                $_SESSION['nm']=$data['email'];
                    echo "<script>location.href='CP_main.php';</script>";  
            }
            else
            {
                echo "<script>
                        alert('Username or Password incorrect !');
                      </script>";
            }
        }
        }
    }
    ?>
    <!-- Our Services -->
    <a name="services" style="text-decoration: none;">
        <div class="container-fluid" style="color: black">
            <div class="container services">
                <div class="row">
                    <h1 class="text-center">Our Services &nbsp<i class="glyphicon glyphicon-wrench"></i></h1>
                    <br>
                    <br>
                    <div class="col-sm-4 text-center">
                        <button class="icon-size"><i class="fa fa-thumbs-up icon-size"></i></button>
                        <h3>100% Satisfaction</h3>
                        <p>In case you are not satisfide with our services, we'll do anything which is satisfide our customers.</p>
                    </div>
                    <div class="col-sm-4 text-center">
                        <button class="icon-size"><i class="fa fa-users"></i></button>
                        <h3>Make Connection</h3>
                        <p>We want to make good connection with our clinet and provide well facility.</p>
                    </div>
                    <div class="col-sm-4 text-center">
                        <button class="icon-size"><i class="fa fa-trophy"></i></button>
                        <h3>Achievement</h3>
                        <p>Connect with each and every pepole to help to grow up.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4 text-center">
                        <button class="icon-size"><i class="fa fa-info-circle"></i></button>
                        <h3>Information</h3>
                        <p>Campus Recruitment System is help to every pepole like a student or comapny employee or any College and University.</p>
                    </div>
                    <div class="col-sm-4 text-center">
                        <button class="icon-size"><i class="fa fa-globe"></i></button>
                        <h3>Worldwide</h3>
                        <p>We are provide our facility to worldwide and reach more people.</p>
                    </div>
                    <div class="col-sm-4 text-center">
                        <button class="icon-size"><i class="fa fa-phone"></i></button>
                        <h3>24x7 Service</h3>
                        <p>We are here 24x7 to help you and contact us for any query.</p>
                    </div>
                </div>
            </div>
        </div>
    </a>
    <!-- Conatct Us -->
    <a name="contact" style="text-decoration: none;">
        <div class="container-fluid contactus">
            <div class="container-fluid text-center contactus-details">
                <h1>Contact Us</h1>
                <p>Address: Sectro 58,Shahi Majra,Mohali,Punjab</p>
                <p>Tel: 123-456-7890 | info@mysite.com</p>
                <br>
                <br>
                <h4>Subscribe for Updates and Permotions</h4>
                <input class="input-lg" type="email" name="subscribe" placeholder="Email Address">
                <br>
                <br>
                <input class="btn btn-primary" type="submit" value="Get Updates">
            </div>
        </div>
    </a>
    <footer class="footer panel-footer text-center">
    	<p>Campus Recruitment System &copy 2018 | Privacy Ploicy</p>
    </footer>
</body>
</html>