<?php
session_start();
if ($_SESSION['mobile']=="") {
    header("location:st_login.php");
    exit();  
}
?>


<?php           
if(isset($_GET["email"]) && isset($_GET["token"]))
{
	include("connectivity.php");
	$email=$con->real_escape_string($_GET["email"]);
	$token=$con->real_escape_string($_GET["token"]);

	$data=$con->query("SELECT id FROM student_register WHERE email='$email' AND token='$token'");

	if($data->num_rows > 0)
	{
		$str="studentportal9999872664";
		$str=str_shuffle($str);
        $str=substr($str,0,7);

        $password=sha1($str);

        $con->query("UPDATE student_register SET password='$password',token='' WHERE email='$email'");
         echo "<script>alert('Your New Password is: $str');</script>";

	}else{
	       echo "<script>alert('Please check your link');</script>";
         }
  }else{
  	header("location:index.php");
  }     

  mysqli_close($con);

?>