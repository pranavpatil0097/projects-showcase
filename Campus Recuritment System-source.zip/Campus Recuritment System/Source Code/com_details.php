<?php
session_start();
if ($_SESSION['email']=="") {
    header("location:col_login.php");
    exit();  
}
?>


<!DOCTYPE html>
<html>

<head>
    <title>Company Details</title>
    <script src="jquery.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap.css">
    <link rel="stylesheet" type="text/css" href="bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="college_style.css">
    <script src="bootstrap.js"></script>
    <style type="text/css">
        table th
        {
            width: auto;
            text-align: center;

        }


    </style>
</head>

<body>
   <?php include("col_header.php");?>
        
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 text-center ">
                    <h1>Companies Detail</h1>
                    <div style="overflow-x: auto;">
                    <table class='table table-hover table-striped table-bordered table-responsive' >
                     <tr>
                     <th>Company Name</th>
                     <th>Department</th>
                     <th>Address</th>
                     <th>Contact Detail</th>
                     <th>Job Profile</th>
                     </tr>
                    <?php
                    include("connectivity.php");
                    $sql="select * from companies_detail";
                    $result=mysqli_query($con,$sql); 
                    
              while($row = mysqli_fetch_array($result))
                   {
                     echo "<tr>";
                     echo "<td>" . $row['company_name'] . "</td>";
                     echo "<td>" . $row['department'] . "</td>";
                     echo "<td>" . $row['address'] . "</td>";
                     echo "<td>". $row['contact_detail'] . "</td>";
                     echo "<td>" . $row['requirment'] . "</td>";
                     echo "</tr>";
                   }
                    ?>
                </table>
            </div>

                </div>
            </div>
       </div>
        
    </div>
    <div style="margin-top: 200px;">
        <?php include("col_footer.php");?>
    </div>
     
</body>

</html>