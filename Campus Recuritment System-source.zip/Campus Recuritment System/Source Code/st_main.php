<?php
session_start();
if ($_SESSION['mobile']=="") {
    header("location:st_login.php");
    exit();  
}
?>

<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>

<body>
    <div class="st-main-background">
        <?php include("st_header.php");?>
        <br/>
        <div class="container">
            <div class="row">
                <div class="col-lg-12  st-messages">
                    <div style="border-bottom: 2px solid white">
                        <h1>Latest Notifications</h1>
                    </div>
                    <br/> Dear Student, Your Fee Due/Balance is Rs. 285500 and Your Compounding Fee Balance is Rs. 50/-. As per notification of fee schedule (UMS->FMS->Fee Structure), You are advised to deposit it on or before specific scheduled date, Otherwise your attendance would be blocked immediately after expiry of specific schedule date.Dear Student, Your Fee Due/Balance is Rs. 285500 and Your Compounding Fee Balance is Rs. 50/-. As per notification of fee schedule (UMS->FMS->Fee Structure), You are advised to deposit it on or before specific scheduled date, Otherwise your attendance would be blocked immediately after expiry of specific schedule date.Dear Student, Your Fee Due/Balance is Rs. 285500 and Your Compounding Fee Balance is Rs. 50/-. As per notification of fee schedule (UMS->FMS->Fee Structure), You are advised to deposit it on or before specific scheduled date, Otherwise your attendance would be blocked immediately after expiry of
                </div>
                <div class="col-lg-12 st-messages">
                    <div style="border-bottom: 2px solid white">
                        <h1>My Messages</h1>
                    </div>
                    <br/> Dear Student, Your Fee Due/Balance is Rs. 285500 and Your Compounding Fee Balance is Rs. 50/-. As per notification of fee schedule (UMS->FMS->Fee Structure), You are advised to deposit it on or before specific scheduled date, Otherwise your attendance would be blocked immediately after expiry of specific schedule date.Dear Student, Your Fee Due/Balance is Rs. 285500 and Your Compounding Fee Balance is Rs. 50/-. As per notification of fee schedule (UMS->FMS->Fee Structure), You are advised to deposit it on or before specific scheduled date, Otherwise your attendance would be blocked immediately after expiry of specific schedule date.Dear Student, Your Fee Due/Balance is Rs. 285500 and Your Compounding Fee Balance is Rs. 50/-. As per notification of fee schedule (UMS->FMS->Fee Structure), You are advised to deposit it on or before specific scheduled date, Otherwise your attendance would be blocked immediately after expiry of
                </div>
                <div class="col-lg-12  st-messages">
                    <div style="border-bottom: 2px solid white">
                        <h1>Upcoming Events</h1>
                    </div>
                    <br/> Dear Student, Your Fee Due/Balance is Rs. 285500 and Your Compounding Fee Balance is Rs. 50/-. As per notification of fee schedule (UMS->FMS->Fee Structure), You are advised to deposit it on or before specific scheduled date, Otherwise your attendance would be blocked immediately after expiry of specific schedule date.Dear Student, Your Fee Due/Balance is Rs. 285500 and Your Compounding Fee Balance is Rs. 50/-. As per notification of fee schedule (UMS->FMS->Fee Structure), You are advised to deposit it on or before specific scheduled date, Otherwise your attendance would be blocked immediately after expiry of specific schedule date.Dear Student, Your Fee Due/Balance is Rs. 285500 and Your Compounding Fee Balance is Rs. 50/-. As per notification of fee schedule (UMS->FMS->Fee Structure), You are advised to deposit it on or before specific scheduled date, Otherwise your attendance would be blocked immediately after expiry of
                </div>
            </div>
        </div>
         <div style="margin-top: 150px; margin-left: -15px;margin-right: -15px;">
            <?php include("col_footer.php");?>
        </div>
        <div class="row">
            <div class="col-lg-12 col-sm-12" style="margin-right: 0px;">
                <footer class="st-footer text-center"> Campus Recruitment System @ 2018 ! Privacy Policy</footer>
            </div>
        </div>
    </div>
</body>

</html>