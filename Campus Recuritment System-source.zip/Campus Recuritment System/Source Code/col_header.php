<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
	<title>College Header</title>
	<script src="js/jquery.js"></script>
	<script src="bootstrap/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">   
</head>
<body>
    <nav class="navbar navbar-inverse col-header">
    <a class="navbar-brand" href="#">
           <span style="color: white;" ><b>Welcome</b> <br/>College Admin</span> 
        </a>
  <div class="container-fluid ">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse col-header" id="myNavbar">
      <ul class="nav navbar-nav navbar-brand ">
        <li><a href="index.php">Home</a></li>
        <li><a href="com_details.php">Check For Companies</a></li>
        <li><a href="col_edit_profile.php">Edit Profile</a></li>
        <li><a href="#">Notifications</a></li>
        <li><a href="#">Events</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
         <li>
                <button><a href="logout.php"> logout</a></button>
        </li>
        
      </ul>
    </div>
 
</nav>






</body>
</html>