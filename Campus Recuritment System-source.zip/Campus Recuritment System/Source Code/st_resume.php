<?php
session_start();
if ($_SESSION['mobile']=="") {
    header("location:st_login.php");
    exit();  
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Upload Resume</title>
    </style>
</head>

<body>
    <div class="st-resume-background">
       <?php include("st_header.php");?>
       
        <div class="container">
            <div class="row">
                <div class="col-lg-12" style="height:250px;"></div>
                <div class="col-lg-4"></div>
                <div class="col-lg-4 st-resume">
                    <form method="post">
                        <input type="file" name="upload" value="Choose File">
                        <br/>
                        <input type="submit" name="submit" class="btn-primary">
                        <font>File Should be less than 2 mb.</font>
                    </form>
                </div>
                <div class="col-lg-4"></div>
            </div>
        </div>
         <div style="margin-top: 250px; margin-left: -15px;margin-right: -15px;">
            <?php include("col_footer.php");?>
        </div>
        <div class="row">
            <div class="col-lg-12 col-sm-12" style="margin-right: 0px;">
                <footer class="st-footer text-center"> Campus Recruitment System @ 2018 ! Privacy Policy</footer>
            </div>
        </div>
    </div>
</body>

</html>