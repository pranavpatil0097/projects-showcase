<?php
session_start();
if ($_SESSION['email']=="") {
    header("location:col_login.php");
    exit();  
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit College Profile</title>
</head>

<body>
    <?php include("col_header.php");?>
        <div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-1 col-sm-2"></div>
                <div class="col-lg-10 col-sm-8 college_profile_edit">
                    <h1>Edit Profile</h1>
                    <form method="post">
                        <input type="text" name="" class="form-control" placeholder=" College Name">
                        <br/>
                        <input type="text" name="" class="form-control" placeholder="Admin Name">
                        <br/>
                        <input type="text" name="" class="form-control" placeholder="Address">
                        <br/>
                        <input type="text" name="" class="form-control" placeholder="Mobile">
                        <br/>
                        <input type="text" name="" class="form-control" placeholder="Email">
                        <br/>
                        <input type="text" name="" class="form-control" placeholder="Post"><br/><br/>
                        <input type="submit" name="" value="Update" class="btn-primary form-control"><br/><br/>
                        <input type="reset" name="" value="Reset" class="btn-primary form-control">
                    </form>
                </div>
                <div class="col-lg-1 col-sm-2"></div>
            </div>
        </div>
    </div>
    <?php include("col_footer.php");?>
</body>

</html>