<?php
session_start();
if ($_SESSION['nm']=="") {
    echo "<script>location.href='CP_login.php';</script>";  
}
$conn    = mysqli_connect("localhost", "root", "", "crs") or die("Connection is not established");
$nws      = "select * from news";
$nwsquery = mysqli_query($conn, $nws);

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Show News</title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
	<?php include('CP_navbar.php') ?>
	<div class="container" style="padding-bottom: 4%">
		<h1 class="text-center" style="padding-top: 3%;padding-bottom: 5%">News</h1>
		<?php
		while($news=mysqli_fetch_array($nwsquery))
		{
			echo "<div class='container' style='box-shadow: 5px 5px 5px 5px gray;'>
				<div class='row'>
					<div class='col-sm-6'><h4>".$news['title']."</h4></div>
					<div class='col-sm-6'><h4>".$news['rec_time']."</h4></div>
				</div>
				<div class='row' style='margin-left: 2%'><p><b>".$news['message']."</b></p></div>
				<div class='row' style='margin-left: 1%'><h5><b>Regards :</b>".$news['cpname']."</h5></div></div> <br>";
		}
		?>
	</div>
</body>
<footer class="footer panel-footer text-center">
    <p>Campus Recruitment System &copy 2018 | Privacy Policy</p>
</footer>
</html>