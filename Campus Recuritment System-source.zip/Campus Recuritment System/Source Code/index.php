<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Campus Recruitment System</title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <!-- Details Of Project -->
    <div class="container-fluid proj-details">
        <div class="row">
            <div class="col-sm-6 font-fmly text-danger">
                <img src="images/CRS.png">
            </div>
            <div class="col-sm-6 text-right" style="color: #2b2;font-family: 'Grundschrift-Regular'">
                <i><h4><b>FAILURE</b> is not the opposite of success,<br>
                It is <b>PART</b> of success.</h4></i>
            </div>
        </div>
    </div>
    <!--navbar -->
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse bt-size" id="myNavbar">
                <ul class="nav navbar-nav nav-det">
                    <li class="active"><a href="index.php">Home</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#event">Events</a></li>
                    <li><a href="#news">News</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
                <ul class="nav navbar-nav">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span class="glyphicon glyphicon-user"></span>&nbspLogIn
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="st_login.php">As Student</a></li>
                            <li><a href="CP_login.php">As Company</a></li>
                            <li><a href="col_login.php">As College or University</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggel="dropdown">
                            <span class="glyphicon glyphicon-log-in"></span>&nbspRegister
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="st_register.php">As Student</a></li>
                            <li><a href="CP_Registration.php">As Company</a></li>
                            <li><a href="col_register.php">As College or University</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    <!-- Slider Content -->
    <div class="container-fluid body">
        <div class="carousel slide" id="myCarousel" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
                <li data-target="#myCarousel" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="item active">
                    <img class="img img-responsive" src="images/1.jpeg" alt="Welcome">
                    <div class="carousel-caption">
                        <h1 style="color: orange">Campus Recruitment System</h1>
                    </div>
                    </img>
                </div>
                <div class="item">
                    <img src="images/2.jpg" alt="Welcome">
                    <div class="carousel-caption">
                        <h2 style="color: black">Get Your Dream Job</h2>
                    </div>
                    </img>
                </div>
                <div class="item">
                    <img src="images/3.jpeg" alt="Welcome">
                    <div class="carousel-caption">
                        <h2 style="color: darkgray">Archive Your Goal...!!</h2>
                    </div>
                    </img>
                </div>
            </div>
            <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                <span class="glyphicon glyphicon-chevron-left"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#myCarousel" data-slide="next">
                <span class="glyphicon glyphicon-chevron-right"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    <!-- About Content -->
    <a name="about">
        <div class="container-fluid banner">
            <div class="row banner-details">
                <div class="col-lg-offset-4 col-lg-6 text-center" style="color: white">
                    <h1 class="w3-animate-fading" style="font-size: 50px">About Us</h1>
                    <p style="font-size: 18px"><i>The Campus Recruitment is a new and public base platform. We are started this to help the students,Companies and College or University.
                        Campus Recruitment System is a pleatform which is use to create a student career and achieve the goals. It is also useful for the Companies because companies also want good,Excellent and skilled developed student which is very beneficial for the company and students also. College and University also contact with the company and they ask for the placement drive which is grow the reputation of the college and university.
                        <br>We need your support to startup and when we are grow up it is beacome a big platform for a <b>Student,Company</b> or <b>University</b>.</i>
                    </p>
                </div>
            </div>
        </div>
    </a>
    <?php include('event.php') ?>
    <!-- News -->
    <?php include('news.php') ?>
    <!-- Our Services -->
    <a name="services" style="text-decoration: none;">
        <div class="container-fluid" style="color: black;">
            <div class="container services">
                <div class="row">
                    <h1 class="text-center w3-animate-fading" style="font-size: 50px">Our Goals &nbsp<i class="glyphicon glyphicon-wrench"></i></h1>
                    <br>
                    <br>
                    <div class="col-sm-4 text-center">
                        <button class="icon-size"><i class="fa fa-thumbs-up icon-size"></i></button>
                        <h3>100% Satisfaction</h3>
                        <p>In case you are not satisfide with our services, we'll do anything which is satisfide our customers.</p>
                    </div>
                    <div class="col-sm-4 text-center">
                        <button class="icon-size"><i class="fa fa-users"></i></button>
                        <h3>Make Connection</h3>
                        <p>We want to make good connection with our clinet and provide well facility.</p>
                    </div>
                    <div class="col-sm-4 text-center">
                        <button class="icon-size"><i class="fa fa-trophy"></i></button>
                        <h3>Achievement</h3>
                        <p>Connect with each and every pepole to help to grow up.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4 text-center">
                        <button class="icon-size"><i class="fa fa-info-circle"></i></button>
                        <h3>Information</h3>
                        <p>Campus Recruitment System is help to every pepole like a student or comapny employee or any College and University.</p>
                    </div>
                    <div class="col-sm-4 text-center">
                        <button class="icon-size"><i class="fa fa-globe"></i></button>
                        <h3>Worldwide</h3>
                        <p>We are provide our facility to worldwide and reach more people.</p>
                    </div>
                    <div class="col-sm-4 text-center">
                        <button class="icon-size"><i class="fa fa-phone"></i></button>
                        <h3>24x7 Service</h3>
                        <p>We are here 24x7 to help you and contact us for any query.</p>
                    </div>
                </div>
            </div>
        </div>
    </a>
    <!-- Conatct Us -->
    <a name="contact" style="text-decoration: none;">
        <div class="container-fluid contactus">
            <div class="container-fluid text-center contactus-details">
                <h1 class="w3-animate-fading" style="font-size: 50px">Contact Us</h1>
                <p>Address: Sectro 58,Shahi Majra,Mohali,Punjab</p>
                <p>Tel: 123-456-7890 | info@mysite.com</p>
                <br>
                <br>
                <h4>Subscribe for Updates and Permotions</h4>
                <input class="input-lg" type="email" name="subscribe" placeholder="Email Address">
                <br>
                <br>
                <input class="btn btn-primary" type="submit" value="Get Updates">
            </div>
        </div>
    </a>
    <footer class="footer panel-footer text-center">
        <p>Campus Recruitment System &copy 2018 | Privacy Policy</p>
    </footer>
</body>

</html>
