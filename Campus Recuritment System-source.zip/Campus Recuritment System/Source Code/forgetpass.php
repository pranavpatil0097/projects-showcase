<?php
session_start();
$conn  = mysqli_connect("localhost", "root", "", "crs") or die("Connection is not established");
$q     = "select email from company";
$query = mysqli_query($conn, $q);
while ($data = mysqli_fetch_array($query)) {
    $email = $data['email'];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Forget Password..!</title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/Admin.css">
    <link rel="stylesheet" type="text/css" href="CSS/companyRegistration.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <!-- Navbar -->

    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">
                    <img src="images/logo.png">
                </a>
            </div>
            <div class="collapse navbar-collapse bt-size" id="myNavbar">
                <ul class="nav navbar-nav navbar-s">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <!-- Admin Login -->
    <div class="container-fluid back body">
        <div class="back-dt">
            <div class="container log-div">
                <h1 class="text-center">Forget Password</h1>
                <br>
                <br>
                <form method="POST">
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Username :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="email" size="40" name="username" placeholder="Enter Username">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            New Password :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="password" size="40" name="pass" placeholder="Enter New Password">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Confirm New Password :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="password" size="40" name="pass2" placeholder="Confirm New Password">
                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3 text-center">
                            <input class="btn btn-success" type="submit" name="submit" value="Submit">
                        </div>
                        <div class="col-sm-5">
                            <input class="btn btn-danger" type="reset" name="reset" value="Cancel">
                        </div>
                    </div>
                    <br>
                </form>
            </div>
        </div>
    </div>
    <?php
if (isset($_POST['submit'])) {
    $user  = $_POST['username'];
    $pass  = $_POST['pass'];
    $pass2 = $_POST['pass2'];
    if ($user == $email) {
        if ($pass == $pass2) {
            $newq     = "update company set password='" . $pass . "'where email='" . $user . "'";
            $newquery = mysqli_query($conn, $newq);
            if ($newquery == true) {
                echo "<script>
                                alert('Password Sucessfully Changed');
                              </script>";
            } else {
                echo "<script>
                                alert('Username & Password does not match');
                              </script>";
            }
        }
    }
}
?>
    <footer class="footer panel-footer text-center">
        <p>Campus Recruitment System &copy 2018 | Privacy Ploicy</p>
    </footer>
</body>

</html>