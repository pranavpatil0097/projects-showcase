<?php
session_start();
if ($_SESSION['mobile']=="") {
    header("location:st_login.php");
    exit();  
}
?>


<!DOCTYPE html>
<html>

<head>
    <title></title>
    <style type="text/css">
    body {
        margin-left: 0px;
        margin-top: 0px;
    }

    </style>
</head>

<body>
        <?php include("st_header.php");?>
    <div class="container-fluid st-edit-back">
        <div class="row">
            <div class="col-lg-12" style="height: 300px">
            </div>
            <div class="col-lg-3 col-sm-2">
            </div>
            <div class="col-lg-6 col-sm-8 st-edit">
                <h1>Edit Your Profile</h1>
                <form>
                    <div class="input-group">
                        <span class="input-group-addon" style="width: 100px"> First Name</span>
                        <input type="text" class="form-control" name="" placeholder="Enter First Name">
                    </div>
                    <br/>
                    <div class="input-group">
                        <span class="input-group-addon" style="width: 100px">Last Name</span>
                        <input id="password" type="text" class="form-control" name="password" placeholder="Enter Last Name">
                    </div>
                    <br/>
                    <div class="input-group">
                        <span class="input-group-addon" style="width: 100px">College Id</span>
                        <input type="text" class="form-control" name="" placeholder="College Id">
                    </div>
                    <br/>
                    <div class="input-group">
                        <span class="input-group-addon" style="width: 100px">Email</span>
                        <input type="email" class="form-control" name="" placeholder="example@gmail.com">
                    </div>
                    <br/>
                    <div class="input-group">
                        <span class="input-group-addon" style="width: 100px">Mobile No.</span>
                        <input id="text" type="text" class="form-control" name="password" placeholder="Enter Mobile Number">
                    </div>
                    <br/>
                    <div class="input-group">
                        <span class="input-group-addon" style="width: 100px">Qualification</span>
                        <input id="password" type="text" class="form-control" name="password" placeholder="Higher Qualification">
                    </div>
                    <br/>
                    <div class="input-group">
                        <span class="input-group-addon" style="width: 100px">Address</span>
                        <input id="password" type="text" class="form-control" name="password" placeholder="Street no.,Town,Disst,Teh ">
                    </div>
                    <br/>
                    <div class="btn-group-sm">
                        <input type="submit" value="Submit" name="" class="btn btn-success">&nbsp &nbsp &nbsp &nbsp
                        <input type="Reset" name="" value="Reset" class="btn btn-primary">
                    </div>
                </form>
            </div>
        </div>
          <div style="margin-top: 300px;">
              <?php include("col_footer.php");?>
         </div>
        <div class="row">
            <div class="col-lg-12 col-sm-12" style="margin-right: 0px;">
                <footer class="st-footer text-center"> Campus Recruitment System @ 2018 ! Privacy Policy</footer>
            </div>
        </div>
    </div>
</body>

</html>