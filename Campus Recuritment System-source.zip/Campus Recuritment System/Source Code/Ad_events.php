<?php
session_start();
if ($_SESSION['uid']=="") 
{
    header("location:Ad_login.php");
}
else
{
    $name=$_SESSION['uid'];
}
$conn=mysqli_connect("localhost","root","","crs") or die("Connection is not established");
$q="select * from events";
$query=mysqli_query($conn,$q);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Events Details</title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/Admin.css">
</head>

<body>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">
            		<img src="images/logo.png">
            	</a>
            </div>
            <div class="collapse navbar-collapse bt-size" id="myNavbar">
                <ul class="nav navbar-nav navbar-s">
                    <li><a href="Ad_main.php">Home</a></li>
                    <li><a href="#">Student</a></li>
                    <li><a href="Ad_Company.php">Company</a></li>
                    <li><a href="#">College or University</a></li>
                    <li class="active"><a href="Ad_events.php">Events</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="Ad_logout.php"><span class="glyphicon glyphicon-user"></span>&nbsp<?php echo $name; ?></a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    <!-- Admin Login -->
    <div class="container-fluid cpsize">
        <h1 class="text-center" style="padding-bottom: 3%">Events Details</h1>
        <table class="table table-responsive" border="3" cellpadding="">
                <tr>
                    <td><b>Company Name</b></td>
                    <td><b>Title</b></td>
                    <td><b>Image</b></td>
                    <td><b>Message</b></td>
                    <td><b>Time</b></td>
                    <td><b>Delete Recorde</b></td>
                </tr>
                <?php
                    while ($data=mysqli_fetch_array($query)) 
                    {
                        echo "<tr>";
                        echo "<td>".$data['cpname']."</td>";
                        echo "<td>".$data['title']."</td>";
                        echo "<td>".$data['image']."</td>";
                        echo "<td>".$data['message']."</td>";
                        echo "<td>".$data['rec_time']."</td>";
                        echo "<td><form method='POST'><input type='submit' name='delete' value='Delete' class='btn btn-danger'><input type='hidden' name='id' value='".$data['id']."'></form></td>";
                        echo "</tr>";
                    }
                ?>
            </table>
    </div>
    <?php
    if (isset($_REQUEST['delete'])) 
    {
        $del="Delete from events where id='".$_REQUEST['id']."';";
        $newquery=mysqli_query($conn,$del);
        if ($newquery==true) 
        {
            echo "<script>
                    alert('Recorde Deleted Sucessfully');
                  </script>";
                  header("location:Ad_Company.php");
        }
        else
        {
            echo "<script>
                    alert('Recorde Deleted Faield');
                  </script>";
        }
    }
    ?>
    <footer class="footer panel-footer text-center">
    	<p>Campus Recruitment System &copy 2018 | Privacy Ploicy</p>
    </footer>
</body>
</html>