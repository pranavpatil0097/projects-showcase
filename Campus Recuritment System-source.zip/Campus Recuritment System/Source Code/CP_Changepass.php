<?php
session_start();
$name=$_SESSION['nm'];
$conn=mysqli_connect("localhost","root","","crs") or die("Connection is not established");
$q="select password from company";
$query=mysqli_query($conn,$q);
while ($data=mysqli_fetch_array($query)) 
{
    $pass=$data['password'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Change Password</title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/main.css">
    <link rel="stylesheet" type="text/css" href="CSS/company.css">
    <link rel="stylesheet" type="text/css" href="CSS/companyRegistration.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">
                    <img src="images/logo.png">
                </a>
            </div>
            <div class="collapse navbar-collapse bt-size" id="myNavbar">
                <ul class="nav navbar-nav navbar-s">
                    <li><a href="CP_main.php">Home</a></li>
                    <li><a href="CP_editprofile.php">Edit Profile</a></li>
                    <li class="active"><a href="CP_Changepass.php">Change Password</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#">
                            <span class="glyphicon glyphicon-user"></span>&nbsp<?php echo $name; ?>
                        </a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

	<div class="fot">
		<div class="container change-pass">
			<h3 class="text-center">Change Password</h3><br><br>
		<form method="POST">
			<div class="row">
				<div class="col-sm-2"></div>
				<div class="col-sm-4 text-center "><h5>Old Password :</h5></div>
				<div class="col-sm-4">
					<input class="input-sm input-field" type="password" name="oldpass" placeholder="Enter Old Password">
				</div>
				<div class="col-sm-2"></div>
			</div><br>
			<div class="row">
				<div class="col-sm-2"></div>
				<div class="col-sm-4 text-center"><h5>New Password :</h5></div>
				<div class="col-sm-4">
					<input class="input-sm input-field" type="password" name="newpass" placeholder="Enter New Password">
				</div>
				<div class="col-sm-2"></div>
			</div><br>
			<div class="row">
				<div class="col-sm-2"></div>
				<div class="col-sm-4 text-center"><h5>Confirm New Password :</h5></div>
				<div class="col-sm-4">
					<input class="input-sm input-field" type="password" name="newpass2" placeholder="Confirm New Password">
				</div>
				<div class="col-sm-2"></div>
			</div><br>
			<div class="row">
				<div class="col-sm-2"></div>
				<div class="col-sm-4 text-right">
                    <input class="btn btn-success" type="submit" name="submit" value="Submit">
                </div>
				<div class="col-sm-4">
					<input class="btn btn-danger" type="reset" name="Reset" value="Clear">
				</div>
				<div class="col-sm-2"></div>
			</div><br>
		</form>
	</div>
	</div>
    <?php
        if (isset($_POST['submit'])) 
        {
            $oldpass=$_POST['oldpass'];
            $newpass=$_POST['newpass'];
            $newpass2=$_POST['newpass2'];
            if ($pass==$oldpass) 
            {
                if ($newpass==$newpass2) 
                {
                    $newq="update company set password='".$newpass."'where username='".$name."'";
                    $newquery=mysqli_query($conn,$newq);
                    if ($newquery==true) 
                    {
                        echo "<script>
                                alert('Password Sucessfully Changed');
                              </script>";
                        header("location:CP_main.php");
                    }
                    else
                    {
                        echo "<script>
                                alert('Username or Password does not match !');
                              </script>";
                    }
                }
            }
        }
    ?>
    <footer class="footer panel-footer text-center">
        <p>Campus Recruitment System &copy 2018 | Privacy Ploicy</p>
    </footer>
</body>
</html>