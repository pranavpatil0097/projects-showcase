<?php
session_start();
if ($_SESSION['mobile']=="") {
    header("location:st_login.php");
    exit();  
}
?>


<!DOCTYPE html>
<html>

<head>
    <title></title>
    <style type="text/css">
    .font {
        color: white;
        margin-bottom: 30px;
        margin-top: 200px;
        background-color: rgba(0,0,0,0.7);
        padding: 30px;
    }
    </style>
</head>

<body>
    <div class="st-back">
       <?php include("st_header.php");?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3"></div>
                <div class="col-lg-6">
                    <div class="font">
                    	<h1>Job Opportunities</h1>
                        A student can explore for job opportunities from this website,but student has need to create a account first as a student profile. They can upload their resume which is usable for recuirters to match a profile with their recuirments.Any student can contact with multiple companies at a time. there Are so many requiters which are hiring for warious technical profiles or non-technical profiles.
                   
                    	<h1>Recuirters</h1>
                    	There are N number of companies which are hiring various profile employees.Check your eligibility for the post which are appearing on "check job" portal.Match your profile with company recruitment then apply for that. 
                   
                    	<h1>Colleges</h1>
                    	A college can place their students in MNC companies,A college authirity and company can contact with each other,They can grow their bussiness.   

                    </div>
                </div>
                <div class="col-lg-3"></div>
            </div>
        </div>
         <div style="margin-top: 300px;">
             <?php include("col_footer.php");?>
        </div>
         <div class="row">
        <div class="col-lg-12 col-sm-12" style="margin-right: 0px;">
            <footer class="st-footer text-center"> Campus Recruitment System @ 2018 ! Privacy Policy</footer>
        </div>
    </div>
    </div>
</body>

</html>