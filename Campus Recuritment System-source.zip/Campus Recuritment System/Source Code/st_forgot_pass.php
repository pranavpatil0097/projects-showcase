<?php
session_start();
if ($_SESSION['mobile']=="") {
    header("location:st_login.php");
    exit();  
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Forget Password..!</title>
<body>
     <?php include("st_header.php");?>
    <!-- Admin Login -->
    <div class="container-fluid back body" style="margin-top: px;">
        
        <div class="col-login-background">
            <div class="container">
                <div class="col-login">
                <h1 class="text-center">Forget Password</h1>
                <br>
                <br>
                <form method="post">
                     <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Student Name:
                        </div>
                        <div class="col-sm-5">
                            <input class="form-control" type="text" size="40" name="username" placeholder="Enter Name">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Email :
                        </div>
                        <div class="col-sm-5">
                            <input class="form-control" type="email" size="40" name="email" placeholder="Enter Email">
                        </div>
                    </div>
                    <br>

                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3 text-center">
                            <input class="btn btn-success" type="submit" name="submit" value="Update">
                        </div>
                        <div class="col-sm-5">
                            <input class="btn btn-danger" type="reset" name="reset" value="Reset">
                        </div>
                    </div>
                    <br>
                </form>
            </div>
            </div>
        </div>
    </div>
    <?php include("col_footer.php");?>
</body>

</html>

<?php
    
    if(isset($_POST['submit']))
    {
      include("connectivity.php");
      $email=$con->real_escape_string($_POST['email']);
      $data=$con->query("SELECT id FROM student_register WHERE email='$email'");

      if($data->num_rows > 0)
       {
        $str="studentportal98553";
        $str=str_shuffle($str);
        $str=substr($str,0,7);
       // $url="http://localhost:8080/crs/st_reset_pass.php?token=$str&email=$email";
        mail($email,"Reset Password" ,"please click here to reset your password"."<br/>".$url,"From:CRS team\r\n");
        $con->query("UPDATE student_register SET token='$str' where email='$email'");
        echo "<script>alert('Please Check Your Email Inbox');</script>";
       }
       else
       {
        echo "<script>alert('please check our inputs');</script>";
       }
    }
      mysqli_close($con);

?>