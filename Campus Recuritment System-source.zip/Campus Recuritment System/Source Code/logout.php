<?php
session_start();
session_destroy();
 if(null!==$_COOKIE['email'] && $_COOKIE['password'])
    {
    	$cookie_email=$_COOKIE['email'];
        $cookie_password=$_COOKIE['password'];
		setcookie('email',$cookie_email,time()-1);
		setcookie('password',$cookie_password,time()-1);

	}
		echo "<script>alert('Logout Successfully);</script>";


?>