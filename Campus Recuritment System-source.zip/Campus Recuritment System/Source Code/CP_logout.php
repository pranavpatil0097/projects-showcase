<?php
session_start();
unset($_SESSION['nm']);
session_destroy();
header("location:CP_login.php");
?>