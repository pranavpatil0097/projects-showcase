<?php
$conn    = mysqli_connect("localhost", "root", "", "crs") or die("Connection is not established");
$delt='DELETE FROM news WHERE rec_time < DATE_SUB(NOW(), INTERVAL 5 DAY);';
$delquery    = mysqli_query($conn, $delt);
$nw_shwo="select * from news order by id desc";
$nw_show_query=mysqli_query($conn,$nw_shwo);
$nw_company = [];
$nw_title   = [];
$nw_msg     = [];
$nw_date    = [];
while ($data=mysqli_fetch_array($nw_show_query)) {
    $nw_company[]=$data['cpname'];
    $nw_title[]=$data['title'];
    $nw_msg[]=$data['message'];
    $nw_date[]=$data['rec_time'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Campus Recruitment System</title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
	<a name="news" style="text-decoration: none;">
        <div class="container-fluid news" style="color: black">
            <div class="container">
                <div class="row text-center event-head">
                    <h1 class="w3-animate-fading" style="font-size: 50px">Latest News</h1></div>
                <div class="row">
                    <div class="col-lg-3">
                        <div class="row">
                            <h3><?php if (!isset($nw_title[0])) {
                                $nw_title[0]="";
                                if ($nw_title[0] == "") {
                                    echo "";
                                } 
                            }else {echo $nw_title[0];} ?></h3>
                        </div>
                        <div class="row">
                            <h5><?php if (!isset($nw_date[0])) {
                                $nw_date[0]="";
                                if ($nw_date[0] == "") {
                                    echo "";
                                } 
                            }else {echo $nw_date[0];} ?></h5>
                        </div>
                        <div class="row">
                            <h5><?php if (!isset($nw_msg[0])) {
                                $nw_msg[0]="";
                                if ($nw_msg[0] == "") {
                                    echo "<h3>No More News is Going on.</h3>";
                                } 
                            }else {echo $nw_msg[0];} ?></h5>
                        </div>
                        <div class="row">
                            <h5><?php if (!isset($nw_company[0])) 
                                    {
                                        $nw_company[0]="";
                                        if ($nw_company[0]=="") 
                                            {
                                                echo "";
                                            } 
                                    } else {echo "<b>Regards :</b>".$nw_company[0];} ?></h5>
                        </div>
                    </div>
                    <div class="col-lg-1"></div>
                    <div class="col-lg-3">
                        <div class="row">
                            <h3><?php if (!isset($nw_title[1])) {
                                $nw_title[1]="";
                                if ($nw_title[1] == "") {
                                    echo "";
                                } 
                            }else {echo $nw_title[1];} ?></h3>
                        </div>
                        <div class="row">
                            <h5><?php if (!isset($nw_date[1])) {
                                $nw_date[1]="";
                                if ($nw_date[1] == "") {
                                    echo "";
                                } 
                            }else {echo $nw_date[1];} ?></h5>
                        </div>
                        <div class="row">
                            <h5><?php if (!isset($nw_msg[1])) {
                                $nw_msg[1]="";
                                if ($nw_msg[1] == "") {
                                    echo "<h3>No More News is Going on.</h3>";
                                } 
                            }else {echo $nw_msg[1];} ?></h5>
                        </div>
                        <div class="row">
                            <h5><?php if (!isset($nw_company[1])) 
                                    {
                                        $nw_company[1]="";
                                        if ($nw_company[1]=="") 
                                            {
                                                echo "";
                                            } 
                                    } else {echo "<b>Regards :</b>".$nw_company[1];} ?></h5>
                        </div>
                    </div>
                    <div class="col-lg-1"></div>
                    <div class="col-lg-3">
                        <div class="row">
                            <h3><?php if (!isset($nw_title[2])) {
                                $nw_title[2]="";
                                if ($nw_title[2] == "") {
                                    echo "";
                                } 
                            }else {echo $nw_title[2];} ?></h3>
                        </div>
                        <div class="row">
                            <h5><?php if (!isset($nw_date[2])) {
                                $nw_date[2]="";
                                if ($nw_date[2] == "") {
                                    echo "";
                                } 
                            }else {echo $nw_date[2];} ?></h5>
                        </div>
                        <div class="row">
                            <h5><?php if (!isset($nw_msg[2])) {
                                $nw_msg[2]="";
                                if ($nw_msg[2] == "") {
                                    echo "<h3>No More News is Going on.</h3>";
                                } 
                            }else {echo $nw_msg[2];} ?></h5>
                        </div>
                        <div class="row">
                            <h5><?php if (!isset($nw_company[2])) 
                                    {
                                        $nw_company[2]="";
                                        if ($nw_company[2]=="") 
                                            {
                                                echo "";
                                            } 
                                    } else {echo "<b>Regards :</b>".$nw_company[2];} ?></h5>
                        </div>
                    </div>
                    <div class="col-lg-1"></div>
                </div>
            </div>
        </div>
    </a>
</body>
</html>