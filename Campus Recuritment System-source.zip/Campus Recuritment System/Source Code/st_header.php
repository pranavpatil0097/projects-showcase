<!DOCTYPE html>
<html>
<head>
	<title>Student Header</title>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
	<script src="js/jquery.js"></script>
	<script src="bootstrap/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">  
</head>
<body>
	 <div class="jumbotron st-nav">
            <div style="position: absolute; padding-top: 0px;">
                <img src="images/st_login.jpeg" class="img-thumbnail profile img img-responsive " style="height: 100px; width: 100px; margin-left: 70px;">
                <br/>
                <h3 style="padding-left:50px; color: white;">Jasvir Singh</h3>
            </div>
            <div>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" style="position: absolute; margin-left: 100px;" id="nav">
                <nav>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="st_edit_profile.php">Edit Profile</a></li>
                        <li><a href="st_ch_password.php">Change Password</a></li>
                        <li><a href="st_guidlines.php">Guidlines</a></li>
                        <li><a href="st_resume.php">Upload Resume</a></li>
                        <li><a href="com_details.php">Check For Jobs</a></li>
                        <li><a href="logout.php">LogOut</a></li>
                    </ul>
                </nav>
            </div>
        </div>
</body>
</html>