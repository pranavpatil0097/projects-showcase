<?php
$conn=mysqli_connect("localhost","root","","crs") or die("Connection is not established");
$q="select * from admin";
$query=mysqli_query($conn,$q);
 while ($data=mysqli_fetch_array($query)) 
    {
        $chk_user=$data['username'];
        $chk_pass=$data['password'];
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Admin Login</title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/Admin.css">
    <link rel="stylesheet" type="text/css" href="CSS/companyRegistration.css">
</head>

<body>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">
            		<img src="images/logo.png">
            	</a>
            </div>
            <div class="collapse navbar-collapse bt-size" id="myNavbar">
                <ul class="nav navbar-nav navbar-s">
                    <li><a href="index.php">Home</a></li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    <!-- Admin Login -->
    <div class="container-fluid back body">
        <div class="back-dt">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4"></div>
                    <div class="col-lg-4 log-div">
                    	<h1 class="heading">Admin LogIn</h1><br>
                        <form method="POST">
                            <div class="input-group">
                            <span class="input-group-addon input-field"><i class="glyphicon glyphicon-user"></i></span>
                            <input class="input-sm input-field" type="text" placeholder="Enetr Your Email" name="user">
                        </div><br>
                        <div class="input-group">
                            <span class="input-group-addon input-field"><i class="glyphicon glyphicon-lock"></i></span>
                            <input class="input-sm input-field" type="password" placeholder="Enter Your Password" name="pass">
                        </div><br>
                        <button class="btn btn-primary" type="submit" name="login">Login</button>&nbsp &nbsp
                        <button class="btn btn-danger" type="button">Forget Password ?</button>
                        </form>
                    </div>
                    <div class="col-lg-4"></div>
                </div>
            </div>
        </div>
    </div>
    <?php
    if (isset($_POST['login'])) 
    {
        $user=$_POST['user'];
        $pass=$_POST['pass'];

        if ($user==$chk_user && $pass==$chk_pass) 
        {
            session_start();
            $_SESSION['uid']=$_POST['user'];
            echo "<script>location.href='Ad_main.php';</script>";
        }
        else
        {
            echo "<script>
        alert('Username or Password incorrect !');
    </script>";
        }
    }
    ?>
    <footer class="footer panel-footer text-center">
    	<p>Campus Recruitment System &copy 2018 | Privacy Ploicy</p>
    </footer>
</body>

</html>