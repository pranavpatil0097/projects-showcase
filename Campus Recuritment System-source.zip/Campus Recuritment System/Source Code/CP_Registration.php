<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Company Registration</title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/main.css">
    <link rel="stylesheet" type="text/css" href="CSS/companyRegistration.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">
                    <img src="images/logo.png">
                </a>
            </div>
            <div class="collapse navbar-collapse bt-size" id="myNavbar">
                <ul class="nav navbar-nav navbar-s">
                    <li><a href="index.php">Home</a></li>
                    <li><a href="#services">Services</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                            <span class="glyphicon glyphicon-user"></span>&nbspLogIn
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="st_login.php">As Student</a></li>
                            <li><a href="CP_login.php">As Company</a></li>
                            <li><a href="col_login.php">As College or University</a></li>
                        </ul>
                    </li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggel="dropdown">
                            <span class="glyphicon glyphicon-log-in"></span>&nbspRegister
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="#">As Student</a></li>
                            <li><a href="CP_Registration.php">As Company</a></li>
                            <li><a href="#">As College or University</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
    <!-- Registration Details -->
    <div class="container-fluid company-back body">
        <div class="company-back-dt">
            <div class="container log-div">
                <h1 class="text-center">Registration of Company</h1>
                <br>
                <br>
                <form method="POST">
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Name Of Company :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="text" size="40" name="company-name" placeholder="Name of Comapny">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Name Of Company Employee :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="text" size="40" name="employee-name" placeholder="Name of Employee">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Position Of Employee :
                        </div>
                        <div class="col-sm-5">
                            <select class="input-field" name="employee-pos">
                                <option value="0"><-- Select one --></option>
                                <option value="CEO">CEO</option>
                                <option value="COO">COO</option>
                                <option value="Director">Director</option>
                                <option value="Marketing Manager">Marketing Manager</option>
                                <option value="Chief Financial Officer">Chief Financial Officer</option>
                                <option value="Production Manager">Production Manager</option>
                                <option value="HR">HR</option>
                                <option value="Senior Technical Supervisior">Senior Technical Supervisior</option>
                                <option value="Operations Manager">Operations Manager</option>
                                <option value="Purchasing Manager">Purchasing Manager</option>
                                <option value="Professional Staff">Professional Staff</option>
                                <option value="Receptionist">Receptionist</option>
                            </select>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Industry :
                        </div>
                        <div class="col-sm-5">
                            <select class="input-field" name="industry">
                                <option value="0"><-- Select one --></option>
                                <option value="Mobile Development">Mobile Development</option>
                                <option value="Web Development">Web Development</option>
                                <option value="Software Development">Software Development</option>
                                <option value="iOS Development">iOS Development</option>
                                <option value="Information Technology">Information Technology</option>
                                <option value="Marketing">Marketing</option>
                            </select>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            E-mail Of Company :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="email" size="40" name="company-email" placeholder="E-mail of company">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Password :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="password" size="40" name="company-pass" placeholder="Enter Password">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Confirm Password :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="password" size="40" name="company-pass2" placeholder="Confirm Password">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Contact No. :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="text" size="40" name="contact" placeholder="Enter contact no">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Enter Company URL :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="text" size="40" name="url" placeholder="Enter Comapny URL">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Address Of Company :
                        </div>
                        <div class="col-sm-5">
                            <textarea name="address" class="input-field" cols="30" rows="5" placeholder="Enter Address"></textarea>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3 text-center">
                            <input class="btn btn-success" type="submit" name="submit" value="Submit">
                        </div>
                        <div class="col-sm-5">
                            <input class="btn btn-danger" type="reset" name="reset" value="Cancel">
                        </div>
                    </div>
                    <br>
                </form>
            </div>
        </div>
    </div>
    <?php
    if (isset($_POST['submit'])) 
    {
        $cpname=$_POST['company-name'];
        $empname=$_POST['employee-name'];
        $pos=$_POST['employee-pos'];
        $industry=$_POST['industry'];
        $email=$_POST['company-email'];
        $pass=$_POST['company-pass'];
        $pass2=$_POST['company-pass2'];
        $contact=$_POST['contact'];
        $url=$_POST['url'];
        $address=$_POST['address'];
        if ($pass==$pass2) 
        {
            $conn=mysqli_connect("localhost","root","","crs") or die("Connection is not established");
            $q="insert into company(cpname,empname,emp_position,industry,email,password,contact,url,address)values('".$cpname."','".$empname."','".$pos."','".$industry."','".$email."','".$pass."','".$contact."','".$url."','".$address."');";
            $query=mysqli_query($conn,$q);
            if ($query==true) 
            {
                echo "<script>
                        alert('Registration Sucessfully');
                   </script>";
            }
            else
            {
                echo "<script>
                        alert('Registration Failed!');
                      </script>";
            }
        }
        else
        {
            echo "<script>
                    alert('Password does not match!');
                  </script>";
        }
    }
    ?>
    <!-- Our Services -->
    <a name="services" style="text-decoration: none;">
        <div class="container-fluid" style="color: black">
        <div class="container services">
            <div class="row">
                <h1 class="text-center">Our Services &nbsp<i class="glyphicon glyphicon-wrench"></i></h1><br><br>
                <div class="col-sm-4 text-center">
                    <button class="icon-size"><i class="fa fa-thumbs-up icon-size"></i></button>
                    <h3>100% Satisfaction</h3>
                    <p>In case you are not satisfide with our services, we'll do anything which is satisfide our customers.</p>
                </div>
                <div class="col-sm-4 text-center">
                    <button class="icon-size"><i class="fa fa-users"></i></button>
                    <h3>Make Connection</h3>
                    <p>We want to make good connection with our clinet and provide well facility.</p>
                </div>
                <div class="col-sm-4 text-center">
                    <button class="icon-size"><i class="fa fa-trophy"></i></button>
                    <h3>Achievement</h3>
                    <p>Connect with each and every pepole to help to grow up.</p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4 text-center">
                    <button class="icon-size"><i class="fa fa-info-circle"></i></button>
                    <h3>Information</h3>
                    <p>Campus Recruitment System is help to every pepole like a student or comapny employee or any College and University.</p>
                </div>
                <div class="col-sm-4 text-center">
                    <button class="icon-size"><i class="fa fa-globe"></i></button>
                    <h3>Worldwide</h3>
                    <p>We are provide our facility to worldwide and reach more people.</p>
                </div>
                <div class="col-sm-4 text-center">
                    <button class="icon-size"><i class="fa fa-phone"></i></button>
                    <h3>24x7 Service</h3>
                    <p>We are here 24x7 to help you and contact us for any query.</p>
                </div>
            </div>
        </div>
    </div>
    </a>
    <!-- Conatct Us -->
    <a name="contact" style="text-decoration: none;">
        <div class="container-fluid contactus">
        <div class="container-fluid text-center contactus-details">
            <h1>Contact Us</h1>
            <p>Address: Sectro 58,Shahi Majra,Mohali,Punjab</p>
            <p>Tel: 123-456-7890 | info@mysite.com</p>
            <br><br>
            <h4>Subscribe for Updates and Permotions</h4>
            <input class="input-lg" type="email" name="subscribe" placeholder="Email Address"><br><br>
            <input class="btn btn-primary" type="submit" value="Get Updates">
        </div>
    </div>
    </a>
    <footer class="footer panel-footer text-center">
        <p>Campus Recruitment System &copy 2018 | Privacy Ploicy</p>
    </footer>
</body>

</html>