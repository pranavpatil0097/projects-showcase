<?php session_start();?>

<!DOCTYPE html>
<html>

<head>
    <title>college login</title>
    <script src="jquery.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">   
    <script src="bootstrap.js"></script>

</head>

<body>
    <div class="jumbotron col-header">
        <div class="col-logo">
            <h2><img src="images/CRS.png"></h2>
        </div>
        <ul class="text-center">
            <li><a href="">Home</a></li>
            <li><a href="">Notifications</a></li>
            <li><a href="">Events</a></li>
        </ul>
    </div>
   
    
    <div class="container-fluid col-login-background">
        <div class="row">
            <div class="col-lg-12" style="height: 300px;"></div>
            <div class="col-lg-1"></div>
            <div class="col-lg-5 col-sm-8 col-login">
                <h1 style="color:white;">College LogIn</h1>
                <form method="POST">
                    <input type="text" name="userid" class="form-control" placeholder="Login ID">
                    <br/>
                    <input type="password" name="password" class="form-control" placeholder="Password">
                    <br/>
                    <input type="submit" name="login" class="btn-primary form-control" value="LogIn">
                    <input type="Checkbox" name="remember">&nbsp Remember me ?
                </form>
            </div>
            <div class="col-lg-1 col-sm-2"></div>
            <div class="col-lg-3 col-sm-4 text">
                <p>
                    <h1>Hello</h1> College Admin,Please Login Here to Update your Detail or Check our Placement Services.Look Forward For Your College. If ou Dnt have created an account yet,then Firstly <a href="">Create Your Acccount.</a>
                </p>
            </div>
        </div>
    </div>
     <?php include("col_footer.php");?>
</body>
</html>
<?php
include("connectivity.php");
    
if(isset($_POST['login']))
    {

        $email=$_POST['userid'];
        $password=$_POST['password'];
        if( $email=="" && $password=="")
        {
            echo "<script>alert('Please Fill All Fields');</script>";
        }

        $query="select * from college_users where email='$email'";
    
        $result=mysqli_query($con,$query);

        if($result === FALSE) 
          { 
            die('no record fetched'.mysqli_error());
           }
       
        $row=mysqli_fetch_array($result);
        if($row['email'] == $email && $row['mobile'] == $password)
        {
            if(isset($_POST['remember'])){
                setcookie('email',$email,time()+60*60*7);
                setcookie('password',$password,time()+60*60*7);
            }
                session_start();
                $_SESSION['email'] = $row['email'];
                sleep(2);
                header("location: col_portal.php");
        }
        else{
          echo "<script>alert('Invalid Email or password');</script>";
        }
    
         mysqli_close($con);
    }
?>