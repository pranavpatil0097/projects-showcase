<?php
session_start();
if ($_SESSION['nm']=="") {
    echo "<script>location.href='CP_login.php';</script>";  
}
$conn    = mysqli_connect("localhost", "root", "", "crs") or die("Connection is not established");
$name    = $_SESSION['nm'];
$nm      = "select * from company where email='" . $name . "';";
$nmquery = mysqli_query($conn, $nm);
while ($nm = mysqli_fetch_array($nmquery)) {
    if ($name == $nm['email']) {
        $company = $nm['cpname'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Welcome <?php echo $company; ?></title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/main.css">
    <link rel="stylesheet" type="text/css" href="CSS/company.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>

<body>
    <?php include('CP_navbar.php') ?>
    <div class="container-fluid company-back body">
        <h1 style="padding-bottom: 300px;padding-top: 300px" class="text-center w3-animate-fading"><font size="60" color="red">Welcome <b><?php echo $company; ?></b> !</font></h1>
    </div>
    <!-- Start Post Event Model -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Post Events:</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="company-name" class="col-form-label">Company Name:</label>
                            <input type="text" class="form-control" name="cp_name" value="<?php echo $company; ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Title:</label>
                            <input type="text" class="form-control" name="title" id="recipient-name">
                        </div>
                        <div class="form-group">
                            <label for="image" class="col-form-label">Uplode Event Image:</label>
                            <input type="file" name="image"  id="event-image">
                        </div>
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Message:</label>
                            <textarea class="form-control" name="msg" id="message-text"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" name="post_event" class="btn btn-primary">Post</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php
if (isset($_POST['post_event'])) {
    $cpname = $company;
    $title  = $_POST['title'];
    $image  = $_FILES['image']['name'];
    $temp   = $_FILES['image']['tmp_name'];
    move_uploaded_file($temp, "Event_images/" . $image);
    $path = "Event_images/" . $image;
    $msg  = $_POST['msg'];

    if ($cpname=="" || $title=="" || $image=="" || $msg=="") {
         echo "<script>
                alert('Please first fill all details. Thanks!');
                </script>";
    }
    else{
        $q     = "insert into events(cpname,title,image,message) values('" . $cpname . "','" . $title . "','" . $image . "','" . $msg . "');";
        $query = mysqli_query($conn, $q);
        if ($query == true) {
            echo "<script>
                    alert('Event Post Sucessfull');
                  </script>";
        } 
        else {
        echo "<script>
                    alert('Event Post Failed');
                  </script>";
        }
    }
}
?>
    <!-- Start Post News Modal -->
    <div class="modal fade" id="news" role="dialog" aria-labelledby="newsLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="newssLabel">Post News:</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST">
                        <div class="form-group">
                            <label for="company-name" class="col-form-label">Company Name:</label>
                            <input type="text" class="form-control" name="cp_nm" value="<?php echo $company; ?>" disabled>
                        </div>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Title:</label>
                            <input type="text" name="title" class="form-control" id="recipient-name">
                        </div>
                        <div class="form-group">
                            <label for="message-text" class="col-form-label">Message:</label>
                            <textarea class="form-control" name="msg" id="message-text"></textarea>
                        </div>
                        <div class="modal-footer">
                            <input type="reset" name="close" class="btn btn-secondary" data-dismiss="modal" value="Close">
                            <input type="submit" name="post_news" class="btn btn-primary" value="Post">
                        </div>
                    </form>
                    <?php
                    if (isset($_POST['post_news'])) 
                    {
                        $nw_cpname=$company;
                        $nw_title=$_POST['title'];
                        $nw_msg=$_POST['msg'];
                        if ($nw_cpname=="" || $nw_title=="" || $nw_msg=="") {
                            echo "<script>
                                    alert('Please first fill all details. Thanks!');
                                   </script>";
                        }
                        else{
                            $nw_q="insert into news(cpname,title,message) values ('".$nw_cpname."','".$nw_title."','".$nw_msg."')";
                            $nw_query=mysqli_query($conn,$nw_q);
                            if ($nw_query==true) {
                                echo "<script>
                                        alert('News Post Sucessfull');
                                        </script>";
                            }
                            else{
                                echo "<script>
                                        alert('Sorry News Post Faield');
                                        </script>";
                            }
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
    <!-- Events -->
    <?php include('event.php') ?>
    
    <!-- News -->
    <?php include('news.php') ?>

    <!-- Conatct Us -->
    <a name="contact" style="text-decoration: none;">
        <div class="container-fluid contactus">
            <div class="container-fluid text-center contactus-details">
                <h1 class="w3-animate-fading" style="font-size: 50px">Contact Us</h1>
                <p>Address: Sectro 58,Shahi Majra,Mohali,Punjab</p>
                <p>Tel: 123-456-7890 | info@mysite.com</p>
                <br>
                <br>
                <h4>Subscribe for Updates and Permotions</h4>
                <input class="input-lg" type="email" name="subscribe" placeholder="Email Address">
                <br>
                <br>
                <input class="btn btn-primary" type="submit" value="Get Updates">
            </div>
        </div>
    </a>
    <footer class="footer panel-footer text-center">
        <p>Campus Recruitment System &copy 2018 | Privacy Ploicy</p>
    </footer>
</body>

</html>