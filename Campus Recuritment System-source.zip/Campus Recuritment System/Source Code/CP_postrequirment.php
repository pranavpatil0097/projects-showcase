<?php
session_start();
if ($_SESSION['nm']=="") {
    echo "<script>location.href='CP_login.php';</script>";  
}
$name    = $_SESSION['nm'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <title>Post Requirment</title>
    <script src="jquery-3.3.1.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap-3.3.7-dist/css/bootstrap.css">
    <script src="bootstrap-3.3.7-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="CSS/navbar.css">
    <link rel="stylesheet" type="text/css" href="CSS/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <style type="text/css">
    	.body
		{
			margin: 0px;
			padding: 0px;
		}
		.cp-post-req
		{
			background: url('images/post-req.jpg') fixed no-repeat;
			background-size: cover;
		}	
		.cp-back-dt
		{
			background-color: rgba(0,0,0,0.5);
			padding-top: 100px;
			padding-bottom: 100px;
			color: white;
		}	
		.post-req-div
		{
			background-color: rgba(0,0,0,0.5);
			border-radius: 15px;
			padding-top: 3%;
			padding-bottom: 3%;
			box-shadow: 4px 4px 4px 4px white;
		}
		.input-field
		{
			background-color: #222;
		}
    </style>
</head>
<body>
	<?php include('CP_navbar.php') ?>
	<!-- Registration Details -->
    <div class="container-fluid cp-post-req body">
        <div class="cp-back-dt">
            <div class="container post-req-div">
                <h1 class="text-center">Post Requirment</h1>
                <br>
                <br>
                <form method="POST">
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Job Profile :
                        </div>
                        <div class="col-sm-5">
                            <input class="input-sm input-field" type="text" size="40" name="job-profile" placeholder="Job Profile">
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3">
                            Skills :
                        </div>
                        <div class="col-sm-5">
                            <textarea name="skills" class="input-field" cols="30" rows="5" placeholder="Enter Skills"></textarea>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-offset-3 col-sm-3 text-center">
                            <input class="btn btn-success" type="submit" name="submit" value="Submit">
                        </div>
                        <div class="col-sm-5">
                            <input class="btn btn-danger" type="reset" name="reset" value="Cancel">
                        </div>
                    </div>
                    <br>
                </form>
            </div>
        </div>
    </div>
    <?php
    if (isset($_POST['submit'])) 
    {
    	$email=$name;
    	$job_profile=$_POST['job-profile'];
    	$skills=$_POST['skills'];
    	if ($job_profile == "" || $skills == "") 
    	{
    		echo "<script>
        			alert('Please fill all details');
    			</script>";
    	}
    	else
    	{
    		$conn    = mysqli_connect("localhost", "root", "", "crs") or die("Connection is not established");
    		$postq="insert into requirment(job_profile,skills,email) values('".$job_profile."','".$skills."','".$email."')";
    		$postquery=mysqli_query($conn,$postq);
    		if ($postquery==true) 
    		{
    			echo "<script>
        			alert('Requirment Post Sucess');
    			</script>";
    			echo "<script>location.replace('CP_main.php');</script>";
    		}
    		else
    		{
    			echo "<script>
        			alert('Requirment Post Failed !');
    			</script>";
    		}
    	}
    }
    ?>
</body>
<footer class="footer panel-footer text-center">
    <p>Campus Recruitment System &copy 2018 | Privacy Policy</p>
</footer>
</html>