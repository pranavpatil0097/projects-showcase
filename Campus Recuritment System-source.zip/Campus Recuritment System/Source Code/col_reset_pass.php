<?php
session_start();
if ($_SESSION['email']=="") {
    header("location:col_login.php");
    exit();  
}
?>


<?php           
if(isset($_GET["email"]) && isset($_GET["token"]))
{
	include("connectivity.php");
	$email=$con->real_escape_string($_GET["email"]);
	$token=$con->real_escape_string($_GET["token"]);

	$data=$con->query("SELECT id FROM college_users WHERE email='$email' AND token='$token'");

	if($data->num_rows > 0)
	{
		$str="12345665lkjbhdghdf";
		$str=str_shuffle($str);
        $str=substr($str,0,5);

        $password=sha1($str);

        $con->query("UPDATE college_users SET password='$password',token='' WHERE email='$email'");
         echo "<script>alert('your New Password is: $str');</script>";

	}else{
	       echo "<script>alert('please check your link');</script>";
         }
  }else{
  	header("location:index.php");
  }     

  mysqli_close($con);

?>