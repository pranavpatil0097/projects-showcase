
<!DOCTYPE html>
<html>

<head>
    <title>Student Login</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="icon" type="image/gif/png" href="images/logo.png">
    <script src="js/jquery.js"></script>
    <script src="bootstrap/bootstrap.js"></script>
    <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="bootstrap/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
    <div class="jumbotron st-nav">
        <div class="crs-logo">
            <img class="img-responsive" src="images/CRS.png" style="position: absolute;">
        </div>
        <div>
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#nav">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="collapse navbar-collapse" style="" id="nav">
            <nav class="text-right">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="">Guidlines</a></li>
                    <li><a href="com_details.php">Check For Jobs</a></li>
                    <li><a href="st_register.php">Register</a></li>
                </ul>
            </nav>
        </div>
    </div>
    <div class="container-fluid st-login-back">
        <div class="row">
            <div class="col-lg-12" style="height: 200px;"></div>
            <div class="col-lg-1 col-sm-1"></div>
            <div class="col-lg-4 col-sm-3">
                <div class="st-login">
                    <form>
                        <h1>Student Login</h1>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                            <input id="email" type="text" class="input-lg" name="email" placeholder="Login Id">
                        </div>
                        <br/>
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                            <input id="password" type="password" class="input-lg" name="password" placeholder="Password">
                        </div>
                        <br/>
                        <div class="btn-group-sm">
                            <input type="submit" value="LogIn" name="" class="btn btn-primary">
                            <input type="submit" name="" value="Forgot Pasword ?" class="btn btn-primary">
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-4 st-login-text">
                <h3>Dear</h3> Student Login here to see the opportunities for your job profile
                if you are not registeres then please <a href="">register</a> ourself first.  
                
            </div>
        </div>
        <div style="margin-top: 150px; margin-left: -15px;margin-right: -15px;">
            <?php include("col_footer.php");?>
        </div>
        <div class="row">
            <div class="col-lg-12 col-sm-12" style="margin-right: 0px;">
                <footer class="st-footer text-center"> Campus Recruitment System @ 2018 ! Privacy Policy</footer>
            </div>
        </div>
    </div>
</body>

</html>

<?php

include("connectivity.php");
    
if(isset($_POST['login']))
    {

        $email=$_POST['st_id'];
        $password=$_POST['password'];
        $query="select * from college_users where email='$email'";
    
        $result=mysqli_query($con,$query);

        if($result === FALSE) 
          { 
            die('no record fetched'.mysqli_error());
           }
       
        $row=mysqli_fetch_array($result);
        if($row['email'] == $email && $row['mobile'] == $password)
        {
            if(isset($_POST['remember'])){
                setcookie('email',$email,time()+60*60*7);
                setcookie('password',$password,time()+60*60*7);
            }
                session_start();
                $_SESSION['mobile'] = $row['mobile'];
                header("location: col_portal.php");
        }
        else{
          echo "<script>alert('Invalid Email or password')</script>";
        }
    
         mysqli_close($con);
    }
?>