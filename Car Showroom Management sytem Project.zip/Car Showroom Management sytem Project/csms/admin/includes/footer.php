 <div class="text-right">
        <div class="credits">
        <p>© 2019 Car Showroom. All rights reserved.</p>
        </div>
      </div>